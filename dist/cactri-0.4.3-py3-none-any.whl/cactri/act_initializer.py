from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .utils.validation import validate_read_counts


@dataclass(slots=True)
class ACTInitialization:
    """Topology-free initialization result for :class:`CactriACT`."""

    parent_vector: np.ndarray
    active_clones: np.ndarray
    mutation_origins: np.ndarray
    cell_clone_assignments: np.ndarray
    genotype_matrix: np.ndarray
    clone_centroids: np.ndarray


class ACTInitializer:
    """Topology-free initializer for an overfitted arbitrary clonal tree.

    The initializer first converts per-cell read counts into mutation-presence
    probabilities, optionally pools evidence over supplied cell groups, clusters
    the resulting observational units without assuming a tree, infers an acyclic
    parent vector from profile inclusion, and finally assigns each mutation to
    the active origin whose descendant pattern maximizes its binomial read
    likelihood.  It is intentionally independent of the BCR initializer.
    """

    def __init__(
        self,
        *,
        k_max: int,
        initial_active_clones: int | None = None,
        p_present: float = 0.5,
        p_absent: float = 0.001,
        min_total_depth: int = 1,
        max_iter: int = 50,
        random_state: int | None = None,
        eps: float = 1e-12,
    ) -> None:
        if k_max < 2:
            raise ValueError("k_max must be at least 2 (reference plus one clone).")
        if initial_active_clones is not None and not 2 <= initial_active_clones <= k_max:
            raise ValueError("initial_active_clones must lie in [2, k_max].")
        if not 0 < p_absent < p_present < 1:
            raise ValueError("require 0 < p_absent < p_present < 1.")
        if min_total_depth < 0:
            raise ValueError("min_total_depth must be nonnegative.")
        if max_iter < 1:
            raise ValueError("max_iter must be positive.")
        self.k_max = int(k_max)
        self.initial_active_clones = initial_active_clones
        self.p_present = float(p_present)
        self.p_absent = float(p_absent)
        self.min_total_depth = int(min_total_depth)
        self.max_iter = int(max_iter)
        self.eps = float(eps)
        self.rng = np.random.default_rng(random_state)
        self.result_: ACTInitialization | None = None

    def fit(
        self,
        alt_counts: np.ndarray,
        total_counts: np.ndarray,
        *,
        group_assignments: np.ndarray | None = None,
    ) -> "ACTInitializer":
        alt = np.asarray(alt_counts, dtype=np.int64)
        total = np.asarray(total_counts, dtype=np.int64)
        if alt.ndim != 2:
            raise ValueError("alt_counts and total_counts must be two-dimensional.")
        alt, total = validate_read_counts(alt, total, n_cells=alt.shape[0])
        n_cells, n_snv = alt.shape
        if n_cells < 1 or n_snv < 1:
            raise ValueError("mutation matrices cannot be empty.")

        unit_alt = alt
        unit_total = total
        cell_to_unit: np.ndarray | None = None
        if group_assignments is not None:
            groups = np.asarray(group_assignments, dtype=np.int64)
            if groups.shape != (n_cells,):
                raise ValueError("group_assignments must have shape (n_cells,).")
            _, cell_to_unit = np.unique(groups, return_inverse=True)
            n_units = int(cell_to_unit.max()) + 1
            unit_alt = np.zeros((n_units, n_snv), dtype=np.int64)
            unit_total = np.zeros_like(unit_alt)
            np.add.at(unit_alt, cell_to_unit, alt)
            np.add.at(unit_total, cell_to_unit, total)

        posterior = self._mutation_presence_probabilities(unit_alt, unit_total)
        n_active = self.initial_active_clones
        if n_active is None:
            # Keep an overfitted state, but never allocate more occupied initial
            # components than there are pooled observational units.
            n_active = min(
                self.k_max,
                max(2, int(unit_alt.shape[0]) + 1),
            )
        n_nonreference = n_active - 1

        unit_assignments, centroids = self._cluster_cells(
            posterior, unit_total, n_nonreference
        )
        assignments = (
            unit_assignments
            if cell_to_unit is None
            else unit_assignments[cell_to_unit]
        )
        used = sorted(int(x) for x in np.unique(assignments) if int(x) > 0)
        remap = {old: new for new, old in enumerate(used, start=1)}
        assignments = np.asarray([0 if x == 0 else remap[int(x)] for x in assignments], dtype=np.int64)
        n_active = 1 + len(used)

        active = np.zeros(self.k_max, dtype=bool)
        active[:n_active] = True
        compact_centroids = np.zeros((self.k_max, n_snv), dtype=float)
        compact_centroids[0] = 0.0
        for old, new in remap.items():
            compact_centroids[new] = centroids[old]

        parent = self._infer_parent_vector(compact_centroids, active)
        origins, genotype = self._infer_mutation_origins(
            alt,
            total,
            assignments,
            parent,
            active,
        )
        self.result_ = ACTInitialization(
            parent_vector=parent,
            active_clones=active,
            mutation_origins=origins,
            cell_clone_assignments=assignments,
            genotype_matrix=genotype,
            clone_centroids=compact_centroids,
        )
        self.parent_vector_ = parent.copy()
        self.active_clones_ = active.copy()
        self.mutation_origins_ = origins.copy()
        self.cell_clone_assignments_ = assignments.copy()
        self.genotype_matrix_ = genotype.copy()
        self.clone_centroids_ = compact_centroids.copy()
        return self

    def fit_predict(
        self,
        alt_counts: np.ndarray,
        total_counts: np.ndarray,
        *,
        group_assignments: np.ndarray | None = None,
    ) -> np.ndarray:
        self.fit(alt_counts, total_counts, group_assignments=group_assignments)
        return self.cell_clone_assignments_.copy()

    def to_dict(self) -> dict[str, Any]:
        if self.result_ is None:
            raise RuntimeError("Call fit before to_dict.")
        return {
            "parent_vector": self.parent_vector_.copy(),
            "active_clones": self.active_clones_.copy(),
            "mutation_origins": self.mutation_origins_.copy(),
            "cell_clone_assignments": self.cell_clone_assignments_.copy(),
            "genotype_matrix": self.genotype_matrix_.copy(),
            "clone_centroids": self.clone_centroids_.copy(),
        }

    def _mutation_presence_probabilities(
        self, alt: np.ndarray, total: np.ndarray
    ) -> np.ndarray:
        ref = total - alt
        lp = alt * np.log(self.p_present) + ref * np.log1p(-self.p_present)
        la = alt * np.log(self.p_absent) + ref * np.log1p(-self.p_absent)
        delta = np.clip(lp - la, -60.0, 60.0)
        posterior = 1.0 / (1.0 + np.exp(-delta))
        posterior = np.where(total >= self.min_total_depth, posterior, 0.5)
        return posterior.astype(float)

    def _cluster_cells(
        self,
        posterior: np.ndarray,
        total: np.ndarray,
        n_nonreference: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        n_cells, n_snv = posterior.shape
        k = min(n_nonreference, n_cells)
        centroids = np.zeros((k + 1, n_snv), dtype=float)
        centroids[0] = 0.0
        mutation_burden = posterior.mean(axis=1)
        first = int(np.argmax(mutation_burden))
        centroids[1] = posterior[first]
        selected = [first]
        for cluster in range(2, k + 1):
            distance = np.min(
                np.sum((posterior[:, None, :] - centroids[None, :cluster, :]) ** 2, axis=2),
                axis=1,
            )
            distance[selected] = -1.0
            index = int(np.argmax(distance))
            if distance[index] <= self.eps:
                index = int(self.rng.integers(0, n_cells))
            centroids[cluster] = posterior[index]
            selected.append(index)

        assignments = np.zeros(n_cells, dtype=np.int64)
        observed = total > 0
        for _ in range(self.max_iter):
            old = assignments.copy()
            # Cells with no coverage are allowed to remain at the reference root.
            denom = np.maximum(observed.sum(axis=1, keepdims=True), 1)
            distance = np.sum(
                ((posterior[:, None, :] - centroids[None, :, :]) ** 2)
                * observed[:, None, :],
                axis=2,
            ) / denom
            # A mild root preference prevents every low-information cell from
            # opening a mutation-bearing component.
            distance[:, 0] *= 0.95
            assignments = np.argmin(distance, axis=1).astype(np.int64)
            for cluster in range(1, k + 1):
                idx = assignments == cluster
                if np.any(idx):
                    weights = np.maximum(total[idx], 1)
                    centroids[cluster] = np.average(posterior[idx], axis=0, weights=weights.sum(axis=1))
                else:
                    farthest = int(np.argmax(np.min(distance[:, :cluster], axis=1)))
                    assignments[farthest] = cluster
                    centroids[cluster] = posterior[farthest]
            centroids[0] = 0.0
            if np.array_equal(old, assignments):
                break
        return assignments, centroids

    @staticmethod
    def _infer_parent_vector(centroids: np.ndarray, active: np.ndarray) -> np.ndarray:
        k_max = active.size
        parent = np.full(k_max, -1, dtype=np.int64)
        parent[0] = -1
        active_nonroot = [int(k) for k in np.flatnonzero(active) if int(k) != 0]
        profiles = centroids >= 0.5
        order = sorted(active_nonroot, key=lambda k: (int(profiles[k].sum()), k))
        placed = [0]
        for clone in order:
            target = profiles[clone]
            candidates = []
            for candidate in placed:
                source = profiles[candidate]
                if np.all(~source | target):
                    candidates.append(candidate)
            if candidates:
                chosen = max(candidates, key=lambda c: (int(profiles[c].sum()), -c))
            else:
                chosen = 0
            parent[clone] = int(chosen)
            placed.append(clone)
        return parent

    def _infer_mutation_origins(
        self,
        alt: np.ndarray,
        total: np.ndarray,
        assignments: np.ndarray,
        parent: np.ndarray,
        active: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray]:
        presence = self._ancestor_presence(parent, active)
        candidates = np.asarray([k for k in np.flatnonzero(active) if k != 0], dtype=np.int64)
        alt_by_clone = np.zeros((self.k_max, alt.shape[1]), dtype=float)
        total_by_clone = np.zeros_like(alt_by_clone)
        np.add.at(alt_by_clone, assignments, alt)
        np.add.at(total_by_clone, assignments, total)
        ref_by_clone = total_by_clone - alt_by_clone
        present_ll = alt_by_clone * np.log(self.p_present) + ref_by_clone * np.log1p(-self.p_present)
        absent_ll = alt_by_clone * np.log(self.p_absent) + ref_by_clone * np.log1p(-self.p_absent)
        base = absent_ll.sum(axis=0)
        delta = present_ll - absent_ll
        score = np.empty((alt.shape[1], candidates.size), dtype=float)
        for column, origin in enumerate(candidates):
            score[:, column] = base + presence[origin].astype(float) @ delta
        origins = candidates[np.argmax(score, axis=1)]
        genotype = presence[origins].T.astype(np.int8)
        return origins.astype(np.int64), genotype

    @staticmethod
    def _ancestor_presence(parent: np.ndarray, active: np.ndarray) -> np.ndarray:
        k_max = active.size
        out = np.zeros((k_max, k_max), dtype=np.int8)
        for clone in np.flatnonzero(active):
            node = int(clone)
            visited: set[int] = set()
            while node >= 0:
                if node in visited:
                    raise ValueError("parent vector contains a cycle.")
                visited.add(node)
                out[node, int(clone)] = 1
                node = int(parent[node]) if node != 0 else -1
        out[0] = 0  # the reference root is fixed to the all-zero genotype
        return out
