"""Backward-compatible imports for :mod:`cactri.pruning`."""

from .pruning import GreedyCollapseStep, GreedyTreePruner, GreedyTreePruningResult

__all__ = ["GreedyCollapseStep", "GreedyTreePruner", "GreedyTreePruningResult"]
