from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Any, Literal

import numpy as np

from .act_initializer import ACTInitializer
from .base import Cactri
from .config import CloneMixtureConfig, TrackingConfig

TreeSummaryMethod = Literal["medoid", "majority"]


@dataclass(frozen=True, slots=True)
class ACTMoveConfig:
    """Topology and overfitted-component move frequencies for CactriACT."""

    parent_reassignments: int = 1
    subtree_regrafts: int = 1
    split_attempts: int = 0
    merge_attempts: int = 0
    min_split_cells: int = 4
    depth_penalty: float = 0.0
    degree_penalty: float = 0.0

    def __post_init__(self) -> None:
        for name in (
            "parent_reassignments",
            "subtree_regrafts",
            "split_attempts",
            "merge_attempts",
        ):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be nonnegative.")
        if self.min_split_cells < 2:
            raise ValueError("min_split_cells must be at least 2.")
        if self.depth_penalty < 0 or self.degree_penalty < 0:
            raise ValueError("topology penalties must be nonnegative.")


class CactriACT(Cactri):
    """Cactri with an overfitted arbitrary rooted clonal tree.

    ``k_max`` fixes the number of allocated clone slots. Clone 0 is the
    reference root. By default all slots remain available throughout MCMC,
    cells may occupy any internal or terminal clone, sparse weights empty
    unsupported slots, and redundant clones are deleted only from posterior
    summaries. Experimental dynamic activation can be enabled explicitly.
    """

    def __init__(
        self,
        *,
        k_max: int,
        initial_active_clones: int | None = None,
        activity_prior: tuple[float, float] = (1.0, 9.0),
        dynamic_activity: bool = False,
        global_weight_concentration: float = 0.2,
        move_config: ACTMoveConfig | None = None,
        topology_initializer: ACTInitializer | None = None,
        tree_summary_method: TreeSummaryMethod = "medoid",
        essential_probability_threshold: float = 0.5,
        **kwargs: Any,
    ) -> None:
        if k_max < 2:
            raise ValueError("k_max must be at least 2.")
        if initial_active_clones is not None and not 2 <= initial_active_clones <= k_max:
            raise ValueError("initial_active_clones must lie in [2, k_max].")
        if len(activity_prior) != 2 or min(activity_prior) <= 0:
            raise ValueError("activity_prior must contain two positive values.")
        if global_weight_concentration <= 0:
            raise ValueError("global_weight_concentration must be positive.")
        if tree_summary_method not in {"medoid", "majority"}:
            raise ValueError("tree_summary_method must be 'medoid' or 'majority'.")
        if not 0 < essential_probability_threshold <= 1:
            raise ValueError("essential_probability_threshold must lie in (0, 1].")

        clone_mixture = kwargs.pop("clone_mixture", None)
        if clone_mixture is None:
            clone_mixture = CloneMixtureConfig(
                enabled=True,
                allow_pure_hyperclusters=False,
                residual_base="uniform",
            )
        if not clone_mixture.enabled:
            raise ValueError("CactriACT requires clone_mixture.enabled=True.")
        if clone_mixture.allow_pure_hyperclusters:
            raise ValueError(
                "CactriACT v0.4.2 implements the continuous no-spike mixture; "
                "set allow_pure_hyperclusters=False."
            )

        self.k_max = int(k_max)
        self.dynamic_activity = bool(dynamic_activity)
        self.initial_active_clones = (
            initial_active_clones if self.dynamic_activity else self.k_max
        )
        self.activity_prior = tuple(float(x) for x in activity_prior)
        self.global_weight_concentration = float(global_weight_concentration)
        self.move_config = move_config or ACTMoveConfig()
        self.topology_initializer = topology_initializer
        self.tree_summary_method = tree_summary_method
        self.essential_probability_threshold = float(essential_probability_threshold)

        self.active_clones_ = np.zeros(self.k_max, dtype=bool)
        n_initial = initial_active_clones or min(self.k_max, 3)
        self.active_clones_[:n_initial] = True
        self.parent_vector_ = np.full(self.k_max, -1, dtype=np.int64)
        self.parent_vector_[0] = -1
        for clone in range(1, n_initial):
            self.parent_vector_[clone] = 0
        self.topological_order_ = np.arange(self.k_max, dtype=np.int64)
        self.mutation_origin_: np.ndarray | None = None
        self.mutation_profile_: np.ndarray | None = None
        self.genotype_matrix_: np.ndarray | None = None
        self.global_clone_weights_ = np.zeros(self.k_max, dtype=float)
        self.global_clone_weights_[self.active_clones_] = 1.0 / int(self.active_clones_.sum())
        self.activity_probability_ = float(
            self.activity_prior[0] / sum(self.activity_prior)
        )
        self.act_initializer_: ACTInitializer | None = None
        self._initializer_cell_clones_: np.ndarray | None = None

        self.parent_vector_trace_: list[np.ndarray] = []
        self.active_clone_trace_: list[np.ndarray] = []
        self.mutation_origin_trace_: list[np.ndarray] = []
        self.global_clone_weight_trace_: list[np.ndarray] = []
        self.activity_probability_trace_: list[float] = []
        self.topology_move_attempts_: dict[str, int] = {
            "parent_reassignment": 0,
            "subtree_regraft": 0,
            "split": 0,
            "merge": 0,
        }
        self.topology_move_accepts_: dict[str, int] = {
            "parent_reassignment": 0,
            "subtree_regraft": 0,
            "split": 0,
            "merge": 0,
        }

        kwargs.setdefault("assignment_likelihood", "joint")
        kwargs.setdefault("new_cluster_likelihood", "prior_predictive")
        kwargs.setdefault("p_unobs_beta_prior", (1.0, 999.0))
        super().__init__(
            n_clones=self.k_max,
            clone_mixture=clone_mixture,
            **kwargs,
        )
        self._set_clone_prior_from_global_weights()
        self.mutation_profile_trace_ = self.genotype_state_trace_

    # ------------------------------------------------------------------
    # Initialization and active-support mixture machinery
    # ------------------------------------------------------------------

    def _initialize_genotype_state(self) -> None:
        initializer = self.topology_initializer
        if initializer is None:
            initializer = ACTInitializer(
                k_max=self.k_max,
                initial_active_clones=self.initial_active_clones,
                p_present=float(np.mean(self.p_obs_by_mutation_)),
                p_absent=float(self.p_unobs_),
                random_state=int(self.rng.integers(0, 2**32 - 1)),
                eps=self.eps,
            )
        elif initializer.k_max != self.k_max:
            raise ValueError("topology_initializer.k_max must equal k_max.")
        initializer.fit(
            self.alt_counts_,
            self.total_counts_,
            group_assignments=self.assignments_,
        )
        self.act_initializer_ = initializer
        self.active_clones_ = initializer.active_clones_.copy()
        self.parent_vector_ = initializer.parent_vector_.copy()
        self.mutation_origin_ = initializer.mutation_origins_.copy()
        self._initializer_cell_clones_ = initializer.cell_clone_assignments_.copy()
        if not self.dynamic_activity:
            # Fixed-dimensional overfitted finite mixture: all K_max slots remain
            # available throughout MCMC. Unsupported slots receive sparse global
            # weights and are deleted only from posterior summaries. Slots not
            # occupied by the topology-free initializer begin as root children.
            previously_active = self.active_clones_.copy()
            self.active_clones_[:] = True
            for clone in range(1, self.k_max):
                if not previously_active[clone]:
                    self.parent_vector_[clone] = 0
        self.global_clone_weights_ = np.zeros(self.k_max, dtype=float)
        counts = np.bincount(
            self._initializer_cell_clones_, minlength=self.k_max
        ).astype(float)
        alpha = self.global_weight_concentration / self.k_max
        self.global_clone_weights_[self.active_clones_] = (
            counts[self.active_clones_] + alpha
        )
        self.global_clone_weights_ /= self.global_clone_weights_.sum()
        self._set_clone_prior_from_global_weights()
        self._refresh_mutation_profile()
        self._validate_topology()

    def _initialize_clone_mixture_state(self) -> None:
        if self._initializer_cell_clones_ is None:
            return super()._initialize_clone_mixture_state()
        self.cell_clone_assignments_ = self._initializer_cell_clones_.copy()
        counts = self._clone_counts_by_hypercluster()
        dominant = np.zeros(self.n_hyperclusters, dtype=np.int64)
        active_indices = self._active_indices()
        for h in range(self.n_hyperclusters):
            local = counts[h, active_indices]
            if local.sum() > 0:
                dominant[h] = int(active_indices[int(np.argmax(local))])
            else:
                dominant[h] = int(active_indices[int(np.argmax(self.global_clone_weights_[active_indices]))])
        self.hypercluster_to_clone_ = dominant
        self.mixture_active_ = np.ones(self.n_hyperclusters, dtype=bool)
        self.mixture_presence_rate_ = 1.0
        self._sample_active_mixture_parameters(counts, dominant)
        self._initializer_cell_clones_ = None

    def _active_indices(self) -> np.ndarray:
        return np.flatnonzero(self.active_clones_).astype(np.int64)

    def _set_clone_prior_from_global_weights(self) -> None:
        weights = np.where(self.active_clones_, self.global_clone_weights_, 0.0)
        if weights.sum() <= 0:
            weights = self.active_clones_.astype(float)
        weights = weights / weights.sum()
        self.global_clone_weights_ = weights
        self.clone_prior = weights.copy()
        self.log_clone_prior = np.full(self.k_max, -np.inf, dtype=float)
        active = self.active_clones_ & (weights > 0)
        self.log_clone_prior[active] = np.log(weights[active])

    def _validate_clone_mixture_support(self) -> None:
        if self.clone_mixture.residual_base != "uniform":
            raise ValueError(
                "CactriACT v0.4.2 requires residual_base='uniform'; "
                "topology-dependent residual priors require an additional term "
                "in the collapsed topology transition."
            )

    def _tree_distance_residual_weights(self, dominant: int) -> np.ndarray:
        distance = self._undirected_distances(int(dominant))
        weights = np.zeros(self.k_max, dtype=float)
        active = self.active_clones_.copy()
        active[int(dominant)] = False
        weights[active] = np.exp(
            -self.clone_mixture.tree_distance_decay * distance[active]
        )
        return weights

    def _residual_base_weights(self, dominant: int) -> np.ndarray:
        if not self.active_clones_[int(dominant)]:
            raise ValueError("dominant clone must be active.")
        weights = np.zeros(self.k_max, dtype=float)
        mask = self.active_clones_.copy()
        mask[int(dominant)] = False
        if not np.any(mask):
            return weights
        if self.clone_mixture.residual_base == "tree_distance":
            weights = self._tree_distance_residual_weights(int(dominant))
        else:
            weights[mask] = self.global_clone_weights_[mask]
            if weights.sum() <= 0:
                weights[mask] = 1.0
        weights[~mask] = 0.0
        return weights / weights.sum()

    def _collapsed_active_mixture_log_mass(
        self, counts: np.ndarray, dominant: int
    ) -> float:
        counts = np.asarray(counts, dtype=np.int64)
        active = self.active_clones_
        n_dominant = int(counts[dominant])
        n_residual = int(counts[active].sum() - n_dominant)
        a, b = self.clone_mixture.admixture_mass_prior
        score = self._log_beta_function(a + n_residual, b + n_dominant)
        score -= self._log_beta_function(a, b)
        mask = active.copy()
        mask[dominant] = False
        if not np.any(mask):
            return float(score)
        weights = self._residual_base_weights(dominant)[mask]
        alpha = self.clone_mixture.residual_concentration * weights
        residual_counts = counts[mask].astype(float)
        score += math.lgamma(float(alpha.sum())) - math.lgamma(
            float(alpha.sum() + residual_counts.sum())
        )
        score += float(
            np.sum(
                [
                    math.lgamma(float(x + n)) - math.lgamma(float(x))
                    for x, n in zip(alpha, residual_counts, strict=True)
                ]
            )
        )
        return float(score)

    def _sample_cell_clone_assignments(self) -> None:
        scores = self._cell_clone_mut_loglikelihood()
        scores += self._safe_log_probabilities(
            self.hypercluster_clone_proportions_[self.assignments_]
        )
        scores[:, ~self.active_clones_] = -np.inf
        self.cell_clone_assignments_ = self._sample_rows(scores).astype(np.int64)

    def _sample_clone_mixture_state(self) -> None:
        counts = self._clone_counts_by_hypercluster()
        scores = np.full((self.n_hyperclusters, self.k_max), -np.inf, dtype=float)
        active = self._active_indices()
        for h in range(self.n_hyperclusters):
            for dominant in active:
                scores[h, dominant] = (
                    self.log_clone_prior[dominant]
                    + self._collapsed_active_mixture_log_mass(counts[h], int(dominant))
                )
        dominant = self._sample_rows(scores).astype(np.int64)
        self.hypercluster_to_clone_ = dominant
        self.mixture_active_ = np.ones(self.n_hyperclusters, dtype=bool)
        self.mixture_presence_rate_ = 1.0
        self._sample_active_mixture_parameters(counts, dominant)

    def _sample_active_mixture_parameters(
        self, counts: np.ndarray, dominant: np.ndarray
    ) -> None:
        proportions = np.zeros((self.n_hyperclusters, self.k_max), dtype=float)
        residual = np.zeros_like(proportions)
        admixture = np.zeros(self.n_hyperclusters, dtype=float)
        a, b = self.clone_mixture.admixture_mass_prior
        active = self.active_clones_
        for h in range(self.n_hyperclusters):
            d = int(dominant[h])
            mask = active.copy()
            mask[d] = False
            if not np.any(mask):
                proportions[h, d] = 1.0
                continue
            n_dominant = int(counts[h, d])
            n_residual = int(counts[h, active].sum() - n_dominant)
            epsilon = float(
                np.clip(
                    self.rng.beta(a + n_residual, b + n_dominant),
                    self.eps,
                    1.0 - self.eps,
                )
            )
            weights = self._residual_base_weights(d)[mask]
            alpha = self.clone_mixture.residual_concentration * weights + counts[h, mask]
            draw = self.rng.gamma(shape=np.maximum(alpha, self.eps), scale=1.0)
            draw = np.clip(draw, self.eps, None)
            draw /= draw.sum()
            residual[h, mask] = draw
            admixture[h] = epsilon
            proportions[h, d] = 1.0 - epsilon
            proportions[h, mask] = epsilon * draw
        self.admixture_mass_ = admixture
        self.residual_clone_proportions_ = residual
        self.hypercluster_clone_proportions_ = proportions

    def _new_hypercluster_clone_prior(self) -> np.ndarray:
        return self.global_clone_weights_.copy()

    def _clone_mixture_log_prior(self) -> float:
        counts = self._clone_counts_by_hypercluster()
        a, b = self.clone_mixture.admixture_mass_prior
        total = 0.0
        for h in range(self.n_hyperclusters):
            d = int(self.dominant_clones_[h])
            if not self.active_clones_[d]:
                return -np.inf
            total += float(self.log_clone_prior[d])
            epsilon = float(np.clip(self.admixture_mass_[h], self.eps, 1.0 - self.eps))
            total += (a - 1.0) * math.log(epsilon)
            total += (b - 1.0) * math.log1p(-epsilon)
            total -= self._log_beta_function(a, b)
            pi = np.clip(self.hypercluster_clone_proportions_[h], self.eps, 1.0)
            occupied = counts[h] > 0
            total += float(np.sum(counts[h, occupied] * np.log(pi[occupied])))
        return float(total)

    # ------------------------------------------------------------------
    # Arbitrary-tree genotype model and topology moves
    # ------------------------------------------------------------------

    def _ancestor_presence(
        self,
        parent: np.ndarray | None = None,
        active: np.ndarray | None = None,
    ) -> np.ndarray:
        parent = self.parent_vector_ if parent is None else np.asarray(parent, dtype=np.int64)
        active = self.active_clones_ if active is None else np.asarray(active, dtype=bool)
        out = np.zeros((self.k_max, self.k_max), dtype=np.int8)
        for clone in np.flatnonzero(active):
            node = int(clone)
            seen: set[int] = set()
            while node >= 0:
                if node in seen:
                    raise ValueError("parent vector contains a cycle.")
                seen.add(node)
                out[node, int(clone)] = 1
                node = int(parent[node]) if node != 0 else -1
        out[0] = 0
        return out

    def _descendants(self, node: int, parent: np.ndarray | None = None, active: np.ndarray | None = None) -> set[int]:
        presence = self._ancestor_presence(parent, active)
        return set(int(x) for x in np.flatnonzero(presence[int(node)]))

    def _refresh_mutation_profile(self) -> None:
        if self.mutation_origin_ is None:
            return
        self._update_topological_order()
        presence = self._ancestor_presence()
        if np.any(~self.active_clones_[self.mutation_origin_]) or np.any(self.mutation_origin_ == 0):
            raise ValueError("mutation origins must be active non-reference clones.")
        profile = presence[self.mutation_origin_].T.astype(np.int8)
        profile[~self.active_clones_] = 0
        profile[0] = 0
        self.mutation_profile_ = profile
        self.genotype_matrix_ = profile

    def _genotype_matrix(self) -> np.ndarray:
        if self.mutation_profile_ is None:
            raise RuntimeError("Call prefit before accessing mutation profiles.")
        return self.mutation_profile_

    def _sample_genotype_state(self) -> None:
        self.mutation_origin_ = self._sample_origins_given(
            self.parent_vector_, self.active_clones_, self.current_cell_clone_assignment()
        )
        self._refresh_mutation_profile()
        for _ in range(self.move_config.parent_reassignments):
            self._propose_parent_reassignment(leaf_only=True)
        for _ in range(self.move_config.subtree_regrafts):
            self._propose_parent_reassignment(leaf_only=False)
        if self.dynamic_activity:
            for _ in range(self.move_config.split_attempts):
                self._propose_split()
            for _ in range(self.move_config.merge_attempts):
                self._propose_merge()
        self._refresh_mutation_profile()
        self._renormalize_mixture_support()

    def _origin_prior_weights(
        self, parent: np.ndarray, active: np.ndarray
    ) -> np.ndarray:
        """Sparse origin base proportional to posterior clade mass.

        A uniform origin prior lets empty overfitted slots attract mutations. A
        prior based only on direct clone weight would instead suppress valid
        unsampled ancestors. We therefore use the total global clone weight in
        each node's descendant clade. Empty leaves receive only a numerical
        floor, whereas occupied internal ancestors remain eligible.
        """
        active = np.asarray(active, dtype=bool)
        direct = np.where(active, self.global_clone_weights_, 0.0).astype(float)
        presence = self._ancestor_presence(parent, active).astype(float)
        weights = presence @ direct
        weights[0] = 0.0
        mask = active.copy()
        mask[0] = False
        if weights[mask].sum() <= 0:
            weights[mask] = 1.0
        weights[mask] = np.clip(weights[mask], self.eps, None)
        weights[~mask] = 0.0
        weights /= weights.sum()
        return weights

    def _origin_score_context(
        self, cell_assignments: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Aggregate read terms shared by all topology candidates."""
        alt_by_clone, ref_by_clone = self.accelerator.aggregate_counts(
            np.asarray(cell_assignments, dtype=np.int64),
            self.alt_counts_,
            self.total_counts_,
            self.k_max,
        )
        p_obs = np.clip(self.p_obs_by_mutation_, self.eps, 1.0 - self.eps)
        p_unobs = float(np.clip(self.p_unobs_, self.eps, 1.0 - self.eps))
        present = (
            alt_by_clone * np.log(p_obs)[None, :]
            + ref_by_clone * np.log1p(-p_obs)[None, :]
        )
        absent = alt_by_clone * math.log(p_unobs) + ref_by_clone * math.log1p(-p_unobs)
        return absent.sum(axis=0), present - absent

    def _origin_log_scores(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        cell_assignments: np.ndarray,
        *,
        context: tuple[np.ndarray, np.ndarray] | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return candidate origins and per-mutation log posterior scores."""
        candidates = np.asarray(
            [k for k in np.flatnonzero(active) if k != 0], dtype=np.int64
        )
        if candidates.size == 0:
            raise RuntimeError("ACT requires at least one active non-reference clone.")
        base, delta = (
            self._origin_score_context(cell_assignments)
            if context is None
            else context
        )
        presence = self._ancestor_presence(parent, active)
        origin_weights = self._origin_prior_weights(parent, active)
        log_scores = np.empty((self.n_snv, candidates.size), dtype=float)
        for column, origin in enumerate(candidates):
            log_scores[:, column] = (
                base
                + presence[int(origin)].astype(float) @ delta
                + math.log(float(origin_weights[int(origin)]))
            )
        return candidates, log_scores

    def _sample_origins_given(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        cell_assignments: np.ndarray,
    ) -> np.ndarray:
        candidates, log_scores = self._origin_log_scores(
            parent, active, cell_assignments
        )
        return candidates[self._sample_rows(log_scores)].astype(np.int64)

    def _collapsed_topology_log_target(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        cell_assignments: np.ndarray,
        *,
        context: tuple[np.ndarray, np.ndarray] | None = None,
    ) -> float:
        """Topology target with mutation origins analytically marginalized.

        Cell clone assignments and uniform residual-mixture priors are unchanged
        by a parent move. Summing over origins removes the severe dependence of
        tree proposals on the current origin draw while preserving the exact
        conditional target for the topology block.
        """
        if not self._topology_is_valid(parent, active):
            return -np.inf
        _, scores = self._origin_log_scores(
            parent, active, cell_assignments, context=context
        )
        maximum = np.max(scores, axis=1)
        marginal = maximum + np.log(
            np.exp(scores - maximum[:, None]).sum(axis=1)
        )
        return float(marginal.sum() + self._topology_log_prior(parent, active))

    def _mutation_log_likelihood_for(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        origins: np.ndarray,
        cell_assignments: np.ndarray,
    ) -> float:
        presence = self._ancestor_presence(parent, active)
        profile = presence[np.asarray(origins, dtype=np.int64)].T.astype(float)
        alt = self.alt_counts_.astype(float)
        ref = self.total_counts_.astype(float) - alt
        p_obs = np.clip(self.p_obs_by_mutation_, self.eps, 1.0 - self.eps)
        p_unobs = float(np.clip(self.p_unobs_, self.eps, 1.0 - self.eps))
        genotype = profile[np.asarray(cell_assignments, dtype=np.int64)]
        probability = genotype * p_obs[None, :] + (1.0 - genotype) * p_unobs
        return float(np.sum(alt * np.log(probability) + ref * np.log1p(-probability)))

    def _state_log_target(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        origins: np.ndarray,
        cell_assignments: np.ndarray,
    ) -> float:
        if not self._topology_is_valid(parent, active):
            return -np.inf
        if np.any(~active[np.asarray(origins, dtype=np.int64)]) or np.any(np.asarray(origins) == 0):
            return -np.inf
        ll = self._mutation_log_likelihood_for(parent, active, origins, cell_assignments)
        origin_weights = self._origin_prior_weights(parent, active)
        origin_prior = float(
            np.log(np.clip(origin_weights[np.asarray(origins, dtype=np.int64)], self.eps, 1.0)).sum()
        )
        topology_prior = self._topology_log_prior(parent, active)
        # Global clone weights are a base distribution for the hypercluster-level
        # dominant/residual mixtures; they are not a second global mixture from
        # which every cell clone label is drawn. The first v0.4.2 build added a
        # collapsed Dirichlet--multinomial term over all cell counts here, which
        # double-counted clone allocations and made supported split moves
        # effectively impossible. Topology moves therefore use the mutation
        # likelihood, mutation-origin prior, and explicit topology/activity prior.
        return float(ll + origin_prior + topology_prior)

    def _topology_log_prior(self, parent: np.ndarray, active: np.ndarray) -> float:
        total = 0.0
        if self.dynamic_activity:
            a, b = self.activity_prior
            n_active = int(active[1:].sum())
            n_inactive = int((~active[1:]).sum())
            rho = float(np.clip(self.activity_probability_, self.eps, 1.0 - self.eps))
            total += n_active * math.log(rho) + n_inactive * math.log1p(-rho)
            total += (a - 1.0) * math.log(rho) + (b - 1.0) * math.log1p(-rho)
        depth = self._depths(parent, active)
        total -= self.move_config.depth_penalty * float(depth[active].sum())
        children = self._children(parent, active)
        excess_degree = sum(max(0, len(row) - 2) for row in children)
        total -= self.move_config.degree_penalty * float(excess_degree)
        return float(total)

    def _propose_parent_reassignment(self, *, leaf_only: bool) -> None:
        name = "parent_reassignment" if leaf_only else "subtree_regraft"
        self.topology_move_attempts_[name] += 1
        children = self._children(self.parent_vector_, self.active_clones_)
        nodes = [
            int(k)
            for k in np.flatnonzero(self.active_clones_)
            if int(k) != 0 and (not leaf_only or len(children[int(k)]) == 0)
        ]
        if not nodes:
            return
        node = int(self.rng.choice(nodes))
        descendants = self._descendants(node)
        candidates = [
            int(k)
            for k in np.flatnonzero(self.active_clones_)
            if int(k) not in descendants and int(k) != node and int(k) != int(self.parent_vector_[node])
        ]
        if not candidates:
            return
        proposal = self.parent_vector_.copy()
        proposal[node] = int(self.rng.choice(candidates))
        cells = self.current_cell_clone_assignment()
        context = self._origin_score_context(cells)
        old = self._collapsed_topology_log_target(
            self.parent_vector_, self.active_clones_, cells, context=context
        )
        new = self._collapsed_topology_log_target(
            proposal, self.active_clones_, cells, context=context
        )
        log_hastings = 0.0
        if leaf_only:
            proposed_children = self._children(proposal, self.active_clones_)
            reverse_nodes = [
                int(k)
                for k in np.flatnonzero(self.active_clones_)
                if int(k) != 0 and len(proposed_children[int(k)]) == 0
            ]
            if not reverse_nodes:
                return
            # Candidate-parent counts for the moved leaf are unchanged; only the
            # uniform choice among eligible leaves can be asymmetric because the
            # old and new parents may gain or lose leaf status.
            log_hastings = math.log(float(len(nodes))) - math.log(float(len(reverse_nodes)))
        if math.log(float(self.rng.random())) < min(0.0, new - old + log_hastings):
            self.parent_vector_ = proposal
            candidates, scores = self._origin_log_scores(
                proposal, self.active_clones_, cells, context=context
            )
            self.mutation_origin_ = candidates[
                self._sample_rows(scores)
            ].astype(np.int64)
            self.topology_move_accepts_[name] += 1
            self._refresh_mutation_profile()

    def _propose_split(self) -> None:
        self.topology_move_attempts_["split"] += 1
        inactive = np.flatnonzero(~self.active_clones_)
        inactive = inactive[inactive != 0]
        if inactive.size == 0:
            return
        cell_clones = self.current_cell_clone_assignment().copy()
        counts = np.bincount(cell_clones, minlength=self.k_max)
        sources = np.asarray(
            [
                k
                for k in np.flatnonzero(self.active_clones_)
                if k != 0 and counts[k] >= self.move_config.min_split_cells
            ],
            dtype=np.int64,
        )
        if sources.size == 0:
            return
        source = int(self.rng.choice(sources))
        new_clone = int(self.rng.choice(inactive))
        idx = np.flatnonzero(cell_clones == source)
        subset = self._split_cell_subset(idx)
        if subset.size == 0 or subset.size == idx.size:
            return
        proposed_cells = cell_clones.copy()
        proposed_cells[subset] = new_clone
        proposed_active = self.active_clones_.copy()
        proposed_active[new_clone] = True
        proposed_parent = self.parent_vector_.copy()
        proposed_parent[new_clone] = source
        proposed_origins = self._split_origin_proposal(
            source=source,
            new_clone=new_clone,
            proposed_parent=proposed_parent,
            proposed_active=proposed_active,
            proposed_cells=proposed_cells,
        )
        if not np.any(proposed_origins == new_clone):
            return
        old = self._state_log_target(
            self.parent_vector_, self.active_clones_, self.mutation_origin_, cell_clones
        )
        new = self._state_log_target(
            proposed_parent, proposed_active, proposed_origins, proposed_cells
        )
        if math.log(float(self.rng.random())) < min(0.0, new - old):
            self.active_clones_ = proposed_active
            self.parent_vector_ = proposed_parent
            self.mutation_origin_ = proposed_origins
            self.cell_clone_assignments_ = proposed_cells
            self.global_clone_weights_[new_clone] = self.eps
            self._update_global_clone_weights()
            self._seed_new_clone_in_mixtures(source, new_clone, subset)
            self.topology_move_accepts_["split"] += 1
            self._refresh_mutation_profile()

    def _split_cell_subset(self, indices: np.ndarray) -> np.ndarray:
        indices = np.asarray(indices, dtype=np.int64)

        # Pool the sparse mutation counts over current BCR hyperclusters before
        # choosing the split. This preserves the topology-free mutation model
        # while avoiding nearly random cell-level splits when most cell--locus
        # observations have zero depth.
        groups = self.assignments_[indices]
        unique_groups, inverse = np.unique(groups, return_inverse=True)
        if unique_groups.size >= 2:
            group_sizes = np.bincount(inverse, minlength=unique_groups.size)
            eligible = np.flatnonzero(
                (group_sizes >= self.move_config.min_split_cells)
                & (group_sizes <= indices.size - self.move_config.min_split_cells)
            )
            if eligible.size:
                # A single BCR hypercluster is often a nearly pure seed for a
                # missing mutation clone. Subsequent cell-clone Gibbs updates can
                # recruit other hyperclusters with the same mutation profile.
                balance = group_sizes[eligible].astype(float) * (
                    indices.size - group_sizes[eligible]
                )
                balance /= balance.sum()
                selected = int(self.rng.choice(eligible, p=balance))
                choose = inverse == selected
                if np.any(choose) and not np.all(choose):
                    return indices[choose]

            alt = np.zeros((unique_groups.size, self.n_snv), dtype=np.int64)
            total = np.zeros_like(alt)
            np.add.at(alt, inverse, self.alt_counts_[indices])
            np.add.at(total, inverse, self.total_counts_[indices])
            ref = total - alt
            p1 = np.clip(self.p_obs_by_mutation_, self.eps, 1.0 - self.eps)
            p0 = float(np.clip(self.p_unobs_, self.eps, 1.0 - self.eps))
            delta = (
                alt * np.log(p1)[None, :]
                + ref * np.log1p(-p1)[None, :]
                - alt * math.log(p0)
                - ref * math.log1p(-p0)
            )
            posterior = 1.0 / (1.0 + np.exp(-np.clip(delta, -60.0, 60.0)))
            observed = total > 0
            burden = np.divide(
                (posterior * observed).sum(axis=1),
                np.maximum(observed.sum(axis=1), 1),
            )
            first = int(np.argmax(burden))
            distance = np.sum(
                ((posterior - posterior[first]) ** 2) * observed, axis=1
            ) / np.maximum(observed.sum(axis=1), 1)
            second = int(np.argmax(distance))
            if second != first and distance[second] > self.eps:
                centers = posterior[[first, second]]
                d = np.empty((unique_groups.size, 2), dtype=float)
                for q in range(2):
                    d[:, q] = np.sum(
                        ((posterior - centers[q]) ** 2) * observed, axis=1
                    ) / np.maximum(observed.sum(axis=1), 1)
                group_side = np.argmin(d, axis=1)
                if np.any(group_side == 0) and np.any(group_side == 1):
                    size = np.bincount(inverse, minlength=unique_groups.size)
                    side_size = np.bincount(
                        group_side, weights=size, minlength=2
                    )
                    new_side = int(np.argmin(side_size))
                    choose = group_side[inverse] == new_side
                    if np.any(choose) and not np.all(choose):
                        return indices[choose]

        # Cell-level fallback for a source clone represented by only one BCR
        # hypercluster or by observationally indistinguishable groups.
        alt = self.alt_counts_[indices].astype(float)
        total = self.total_counts_[indices].astype(float)
        fraction = np.divide(alt, total, out=np.zeros_like(alt), where=total > 0)
        variance = np.var(fraction, axis=0)
        locus = int(np.argmax(variance))
        observed = total[:, locus] > 0
        if np.any(observed):
            values = fraction[:, locus]
            threshold = float(np.median(values[observed]))
            choose = values > threshold
        else:
            choose = self.rng.random(indices.size) < 0.5
        if not np.any(choose) or np.all(choose):
            order = self.rng.permutation(indices.size)
            choose = np.zeros(indices.size, dtype=bool)
            choose[order[: max(1, indices.size // 2)]] = True
        return indices[choose]

    def _split_origin_proposal(
        self,
        *,
        source: int,
        new_clone: int,
        proposed_parent: np.ndarray,
        proposed_active: np.ndarray,
        proposed_cells: np.ndarray,
    ) -> np.ndarray:
        """Propose child-specific mutation origins for a clone split.

        Each mutation compares its current origin with the newly activated child
        under the proposed cell partition. This local proposal is deliberately
        conservative: it does not reassign unrelated mutations among all active
        nodes, and therefore avoids the all-origin resampling defect of the first
        v0.4.2 implementation.
        """
        origins = self.mutation_origin_.copy()
        alt_by_clone, ref_by_clone = self.accelerator.aggregate_counts(
            np.asarray(proposed_cells, dtype=np.int64),
            self.alt_counts_,
            self.total_counts_,
            self.k_max,
        )
        p1 = np.clip(self.p_obs_by_mutation_, self.eps, 1.0 - self.eps)
        p0 = float(np.clip(self.p_unobs_, self.eps, 1.0 - self.eps))
        present = (
            alt_by_clone * np.log(p1)[None, :]
            + ref_by_clone * np.log1p(-p1)[None, :]
        )
        absent = alt_by_clone * math.log(p0) + ref_by_clone * math.log1p(-p0)
        delta = present - absent
        presence = self._ancestor_presence(proposed_parent, proposed_active)
        current_score = np.empty(self.n_snv, dtype=float)
        new_score = presence[new_clone].astype(float) @ delta
        for j, origin in enumerate(origins):
            current_score[j] = float(presence[int(origin)].astype(float) @ delta[:, j])
        logit = np.clip(new_score - current_score, -60.0, 60.0)
        probability = 1.0 / (1.0 + np.exp(-logit))
        move = self.rng.random(self.n_snv) < probability
        origins[move] = int(new_clone)
        return origins.astype(np.int64)

    def _propose_merge(self) -> None:
        self.topology_move_attempts_["merge"] += 1
        children = self._children(self.parent_vector_, self.active_clones_)
        candidates = []
        for node in np.flatnonzero(self.active_clones_):
            node = int(node)
            if node == 0 or children[node]:
                continue
            parent = int(self.parent_vector_[node])
            if parent == 0 and np.any(self.mutation_origin_ == node):
                continue
            candidates.append(node)
        if not candidates:
            return
        node = int(self.rng.choice(candidates))
        parent = int(self.parent_vector_[node])
        proposed_cells = self.current_cell_clone_assignment().copy()
        proposed_cells[proposed_cells == node] = parent
        proposed_origins = self.mutation_origin_.copy()
        if parent != 0:
            proposed_origins[proposed_origins == node] = parent
        proposed_active = self.active_clones_.copy()
        proposed_active[node] = False
        proposed_parent = self.parent_vector_.copy()
        proposed_parent[node] = -1
        old = self._state_log_target(
            self.parent_vector_, self.active_clones_, self.mutation_origin_, self.current_cell_clone_assignment()
        )
        new = self._state_log_target(
            proposed_parent, proposed_active, proposed_origins, proposed_cells
        )
        if math.log(float(self.rng.random())) < min(0.0, new - old):
            self.active_clones_ = proposed_active
            self.parent_vector_ = proposed_parent
            self.mutation_origin_ = proposed_origins
            self.cell_clone_assignments_ = proposed_cells
            self.global_clone_weights_[node] = 0.0
            self._replace_clone_in_mixtures(node, parent)
            self._update_global_clone_weights()
            self.topology_move_accepts_["merge"] += 1
            self._refresh_mutation_profile()

    def _seed_new_clone_in_mixtures(self, source: int, new_clone: int, moved_cells: np.ndarray) -> None:
        moved_h = self.assignments_[moved_cells]
        for h in np.unique(moved_h):
            h = int(h)
            row = self.hypercluster_clone_proportions_[h]
            transfer = min(0.05, max(self.eps, 0.5 * row[source]))
            row[source] = max(self.eps, row[source] - transfer)
            row[new_clone] += transfer
            row[~self.active_clones_] = 0.0
            row /= row.sum()
        self._renormalize_mixture_support()

    def _replace_clone_in_mixtures(self, source: int, target: int) -> None:
        self.hypercluster_clone_proportions_[:, target] += self.hypercluster_clone_proportions_[:, source]
        self.hypercluster_clone_proportions_[:, source] = 0.0
        self.residual_clone_proportions_[:, source] = 0.0
        self.hypercluster_to_clone_[self.hypercluster_to_clone_ == source] = target
        self._renormalize_mixture_support()

    def _renormalize_mixture_support(self) -> None:
        if self.hypercluster_clone_proportions_ is None:
            return
        active = self.active_clones_
        self.hypercluster_clone_proportions_[:, ~active] = 0.0
        for h in range(self.n_hyperclusters):
            d = int(self.hypercluster_to_clone_[h])
            if not active[d]:
                d = int(self._active_indices()[np.argmax(self.global_clone_weights_[active])])
                self.hypercluster_to_clone_[h] = d
            row = self.hypercluster_clone_proportions_[h]
            if row.sum() <= 0:
                row[d] = 1.0
            row /= row.sum()
            self.admixture_mass_[h] = 1.0 - row[d]
            residual = row.copy()
            residual[d] = 0.0
            if residual.sum() > 0:
                residual /= residual.sum()
            self.residual_clone_proportions_[h] = residual
        self.mixture_active_ = np.ones(self.n_hyperclusters, dtype=bool)
        self.mixture_presence_rate_ = 1.0

    def _update_genotype_prior_parameters(self) -> None:
        self._update_global_clone_weights()
        if not self.dynamic_activity:
            self.activity_probability_ = 1.0
            return
        a, b = self.activity_prior
        n_active = int(self.active_clones_[1:].sum())
        n_inactive = int((~self.active_clones_[1:]).sum())
        self.activity_probability_ = float(
            np.clip(
                self.rng.beta(a + n_active, b + n_inactive),
                self.eps,
                1.0 - self.eps,
            )
        )

    def _update_global_clone_weights(self) -> None:
        counts = np.bincount(
            self.current_cell_clone_assignment(), minlength=self.k_max
        ).astype(float)
        alpha = np.zeros(self.k_max, dtype=float)
        alpha[self.active_clones_] = self.global_weight_concentration / self.k_max
        draw = np.zeros(self.k_max, dtype=float)
        draw[self.active_clones_] = self.rng.gamma(
            np.maximum(alpha[self.active_clones_] + counts[self.active_clones_], self.eps),
            1.0,
        )
        draw[self.active_clones_] = np.clip(draw[self.active_clones_], self.eps, None)
        draw /= draw.sum()
        self.global_clone_weights_ = draw
        self._set_clone_prior_from_global_weights()

    def _genotype_log_prior(self) -> float:
        active_nonroot = max(int(self.active_clones_.sum()) - 1, 1)
        return float(-self.n_snv * math.log(float(active_nonroot)))

    def _extra_log_prior(self) -> float:
        return self._topology_log_prior(self.parent_vector_, self.active_clones_)

    # ------------------------------------------------------------------
    # Topology validation, contraction, and posterior summaries
    # ------------------------------------------------------------------

    def _update_topological_order(self) -> None:
        """Refresh the active-node topological order followed by inactive slots."""
        if not self._topology_is_valid(self.parent_vector_, self.active_clones_):
            return
        children = self._children(self.parent_vector_, self.active_clones_)
        order: list[int] = []
        queue = [0]
        while queue:
            node = queue.pop(0)
            order.append(int(node))
            queue.extend(sorted(children[node]))
        order.extend(int(k) for k in range(self.k_max) if not self.active_clones_[k])
        self.topological_order_ = np.asarray(order, dtype=np.int64)

    def _children(self, parent: np.ndarray, active: np.ndarray) -> list[list[int]]:
        children: list[list[int]] = [[] for _ in range(self.k_max)]
        for node in np.flatnonzero(active):
            node = int(node)
            if node == 0:
                continue
            p = int(parent[node])
            if p >= 0:
                children[p].append(node)
        return children

    def _depths(self, parent: np.ndarray, active: np.ndarray) -> np.ndarray:
        depth = np.zeros(self.k_max, dtype=np.int64)
        for node in np.flatnonzero(active):
            current = int(node)
            d = 0
            seen: set[int] = set()
            while current != 0:
                if current in seen or current < 0:
                    return np.full(self.k_max, self.k_max + 1, dtype=np.int64)
                seen.add(current)
                current = int(parent[current])
                d += 1
                if d > self.k_max:
                    return np.full(self.k_max, self.k_max + 1, dtype=np.int64)
            depth[int(node)] = d
        return depth

    def _topology_is_valid(self, parent: np.ndarray, active: np.ndarray) -> bool:
        if active.shape != (self.k_max,) or parent.shape != (self.k_max,):
            return False
        if not bool(active[0]) or int(parent[0]) != -1:
            return False
        if int(active.sum()) < 2:
            return False
        for node in range(1, self.k_max):
            if active[node]:
                p = int(parent[node])
                if p < 0 or p >= self.k_max or not active[p] or p == node:
                    return False
            elif int(parent[node]) != -1:
                return False
        depth = self._depths(parent, active)
        return bool(np.all(depth[active] <= self.k_max))

    def _validate_topology(self) -> None:
        if not self._topology_is_valid(self.parent_vector_, self.active_clones_):
            raise ValueError("invalid ACT parent vector or active-clone state.")

    def _undirected_distances(self, source: int) -> np.ndarray:
        children = self._children(self.parent_vector_, self.active_clones_)
        adjacency = [set(row) for row in children]
        for node in np.flatnonzero(self.active_clones_):
            node = int(node)
            if node != 0:
                adjacency[node].add(int(self.parent_vector_[node]))
        distance = np.full(self.k_max, self.k_max + 1, dtype=float)
        distance[source] = 0.0
        queue = [source]
        while queue:
            node = queue.pop(0)
            for nxt in adjacency[node]:
                if distance[nxt] > distance[node] + 1:
                    distance[nxt] = distance[node] + 1
                    queue.append(nxt)
        return distance

    def _essential_mask_for_draw(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        origins: np.ndarray,
        cell_clones: np.ndarray,
    ) -> np.ndarray:
        children = self._children(parent, active)
        occupancy = np.bincount(cell_clones, minlength=self.k_max)
        origin_count = np.bincount(origins, minlength=self.k_max)
        essential = np.zeros(self.k_max, dtype=bool)
        essential[0] = True
        for node in np.flatnonzero(active):
            node = int(node)
            if node == 0:
                continue
            essential[node] = bool(
                occupancy[node] > 0 or origin_count[node] > 0 or len(children[node]) >= 2
            )
        return essential

    def contract_tree(
        self,
        parent: np.ndarray,
        active: np.ndarray,
        origins: np.ndarray,
        cell_clones: np.ndarray,
        *,
        mutation_identifiable: bool = False,
    ) -> dict[str, np.ndarray]:
        parent = np.asarray(parent, dtype=np.int64).copy()
        active = np.asarray(active, dtype=bool).copy()
        origins = np.asarray(origins, dtype=np.int64).copy()
        cells = np.asarray(cell_clones, dtype=np.int64).copy()
        changed = True
        while changed:
            changed = False
            children = self._children(parent, active)
            occupancy = np.bincount(cells, minlength=self.k_max)
            origin_count = np.bincount(origins, minlength=self.k_max)
            for node in [int(x) for x in np.flatnonzero(active) if int(x) != 0]:
                redundant = occupancy[node] == 0 and origin_count[node] == 0 and len(children[node]) <= 1
                zero_change = mutation_identifiable and origin_count[node] == 0 and len(children[node]) <= 1
                if not (redundant or zero_change):
                    continue
                p = int(parent[node])
                if children[node]:
                    child = int(children[node][0])
                    parent[child] = p
                cells[cells == node] = p
                active[node] = False
                parent[node] = -1
                changed = True
                break
        return {
            "parent_vector": parent,
            "active_clones": active,
            "mutation_origins": origins,
            "cell_clone_assignments": cells,
        }

    def _compact_contracted_tree(
        self,
        contracted: dict[str, np.ndarray],
        genotype_matrix: np.ndarray,
    ) -> dict[str, np.ndarray]:
        """Return a reindexed contracted tree and its aligned genotype matrix."""
        parent = np.asarray(contracted["parent_vector"], dtype=np.int64)
        active = np.asarray(contracted["active_clones"], dtype=bool)
        children = self._children(parent, active)
        order: list[int] = []
        queue = [0]
        while queue:
            node = queue.pop(0)
            if not active[node]:
                continue
            order.append(int(node))
            queue.extend(sorted(children[node]))
        original_slots = np.asarray(order, dtype=np.int64)
        mapping = np.full(self.k_max, -1, dtype=np.int64)
        mapping[original_slots] = np.arange(original_slots.size, dtype=np.int64)
        compact_parent = np.full(original_slots.size, -1, dtype=np.int64)
        for new_index, old_node in enumerate(original_slots):
            if old_node != 0:
                compact_parent[new_index] = mapping[int(parent[old_node])]
        compact_cells = mapping[np.asarray(contracted["cell_clone_assignments"], dtype=np.int64)]
        return {
            "original_clone_slots": original_slots,
            "parent_vector": compact_parent,
            "cell_clone_assignments": compact_cells,
            "genotype_matrix": np.asarray(genotype_matrix)[original_slots].copy(),
        }

    def posterior_retained_clone_mask(
        self, *, burn_in: int | float = 0, thin: int = 1, threshold: float | None = None
    ) -> np.ndarray:
        """Return slots retained by posterior essentiality probability."""
        value = self.essential_probability_threshold if threshold is None else float(threshold)
        if not 0 < value <= 1:
            raise ValueError("threshold must lie in (0, 1].")
        probability = self.posterior_clone_essentiality_probabilities(
            burn_in=burn_in, thin=thin
        )
        retained = probability >= value
        retained[0] = True
        return retained

    def _selected_act_trace_indices(self, burn_in: int | float = 0, thin: int = 1) -> np.ndarray:
        n = len(self.parent_vector_trace_)
        if n == 0:
            raise ValueError("ACT topology trace is empty; track genotype_state during fit.")
        lengths = {
            n,
            len(self.active_clone_trace_),
            len(self.mutation_origin_trace_),
            len(self.cell_clone_assignment_trace_),
            len(self.genotype_state_trace_),
        }
        if len(lengths) != 1:
            raise ValueError(
                "ACT posterior tree summaries require aligned parent, active, origin, "
                "cell-clone, and genotype traces; use TrackingConfig.posterior()."
            )
        if isinstance(burn_in, float):
            if not 0 <= burn_in < 1:
                raise ValueError("fractional burn_in must lie in [0,1).")
            start = int(math.floor(n * burn_in))
        else:
            start = int(burn_in)
        if start < 0 or start >= n:
            raise ValueError("burn_in removes all ACT topology draws.")
        if thin < 1:
            raise ValueError("thin must be at least 1.")
        return np.arange(start, n, thin, dtype=np.int64)

    def _draw_clades(self, index: int) -> set[frozenset[int]]:
        parent = self.parent_vector_trace_[index]
        active = self.active_clone_trace_[index]
        cells = self.cell_clone_assignment_trace_[index]
        presence = self._ancestor_presence(parent, active)
        clades: set[frozenset[int]] = set()
        for node in np.flatnonzero(active):
            node = int(node)
            if node == 0:
                continue
            descendants = presence[node].astype(bool)
            member_cells = frozenset(
                int(i) for i in np.flatnonzero(descendants[cells])
            )
            if member_cells:
                clades.add(member_cells)
        return clades

    def posterior_tree_summary(
        self,
        *,
        burn_in: int | float = 0,
        thin: int = 1,
        primary: TreeSummaryMethod | None = None,
    ) -> dict[str, Any]:
        indices = self._selected_act_trace_indices(burn_in, thin)
        clades = [self._draw_clades(int(i)) for i in indices]
        distance = np.zeros((indices.size, indices.size), dtype=float)
        for i in range(indices.size):
            for j in range(i + 1, indices.size):
                d = float(len(clades[i].symmetric_difference(clades[j])))
                distance[i, j] = distance[j, i] = d
        medoid_local = int(np.argmin(distance.sum(axis=1)))
        medoid_index = int(indices[medoid_local])

        support: dict[frozenset[int], float] = {}
        union = set().union(*clades) if clades else set()
        for clade in union:
            support[clade] = float(np.mean([clade in row for row in clades]))
        majority = {clade for clade, value in support.items() if value > 0.5}
        majority_scores = np.asarray(
            [
                sum(support[c] for c in row & majority)
                - sum((1.0 - support[c]) for c in row - majority)
                for row in clades
            ],
            dtype=float,
        )
        majority_local = int(np.argmax(majority_scores))
        majority_index = int(indices[majority_local])

        method = self.tree_summary_method if primary is None else primary
        primary_index = medoid_index if method == "medoid" else majority_index
        essential = self.posterior_clone_essentiality_probabilities(
            burn_in=burn_in, thin=thin
        )
        parent = self.parent_vector_trace_[primary_index].copy()
        active = self.active_clone_trace_[primary_index].copy()
        origins = self.mutation_origin_trace_[primary_index].copy()
        cells = self.cell_clone_assignment_trace_[primary_index].copy()
        sampled_population = self.contract_tree(
            parent, active, origins, cells, mutation_identifiable=False
        )
        mutation_identifiable = self.contract_tree(
            parent, active, origins, cells, mutation_identifiable=True
        )
        selected_genotype = np.asarray(self.genotype_state_trace_[primary_index], dtype=np.int8)
        sampled_population_compact = self._compact_contracted_tree(
            sampled_population, selected_genotype
        )
        mutation_identifiable_compact = self._compact_contracted_tree(
            mutation_identifiable, selected_genotype
        )
        table = [
            {
                "cell_indices": tuple(sorted(clade)),
                "size": len(clade),
                "posterior_support": value,
            }
            for clade, value in sorted(
                support.items(), key=lambda item: (-item[1], -len(item[0]), tuple(item[0]))
            )
        ]
        return {
            "primary_method": method,
            "primary_trace_index": primary_index,
            "medoid_trace_index": medoid_index,
            "majority_trace_index": majority_index,
            "mean_rf_loss_medoid": float(distance[medoid_local].mean()),
            "mean_rf_loss_majority": float(distance[majority_local].mean()),
            "clone_essentiality_probabilities": essential,
            "posterior_retained_clone_mask": self.posterior_retained_clone_mask(
                burn_in=burn_in, thin=thin
            ),
            "clade_support": table,
            "sampled_population_tree": sampled_population,
            "mutation_identifiable_tree": mutation_identifiable,
            "sampled_population_compact": sampled_population_compact,
            "mutation_identifiable_compact": mutation_identifiable_compact,
        }

    def posterior_clone_essentiality_probabilities(
        self, *, burn_in: int | float = 0, thin: int = 1
    ) -> np.ndarray:
        indices = self._selected_act_trace_indices(burn_in, thin)
        total = np.zeros(self.k_max, dtype=float)
        for index in indices:
            total += self._essential_mask_for_draw(
                self.parent_vector_trace_[int(index)],
                self.active_clone_trace_[int(index)],
                self.mutation_origin_trace_[int(index)],
                self.cell_clone_assignment_trace_[int(index)],
            )
        return total / indices.size

    def topology_move_diagnostics(self) -> dict[str, dict[str, float | int]]:
        out: dict[str, dict[str, float | int]] = {}
        for name, attempts in self.topology_move_attempts_.items():
            accepts = self.topology_move_accepts_[name]
            out[name] = {
                "attempts": int(attempts),
                "accepts": int(accepts),
                "acceptance_rate": 0.0 if attempts == 0 else float(accepts / attempts),
            }
        return out

    # ------------------------------------------------------------------
    # Tracking and serialization
    # ------------------------------------------------------------------

    def _genotype_state_for_tracking(self) -> np.ndarray:
        return self.mutation_profile_

    def _clear_subclass_traces(self) -> None:
        self.parent_vector_trace_.clear()
        self.active_clone_trace_.clear()
        self.mutation_origin_trace_.clear()
        self.global_clone_weight_trace_.clear()
        self.activity_probability_trace_.clear()

    def _append_subclass_tracking(self, config: TrackingConfig) -> None:
        if config.genotype_state:
            self.parent_vector_trace_.append(self.parent_vector_.copy())
            self.active_clone_trace_.append(self.active_clones_.copy())
            self.mutation_origin_trace_.append(self.mutation_origin_.copy())
            self.global_clone_weight_trace_.append(self.global_clone_weights_.copy())
            self.activity_probability_trace_.append(float(self.activity_probability_))

    def posterior_summary(
        self,
        *,
        burn_in: int | float = 0,
        thin: int = 1,
        include_partition_medoids: bool = False,
    ) -> dict[str, Any]:
        summary = super().posterior_summary(
            burn_in=burn_in,
            thin=thin,
            include_partition_medoids=include_partition_medoids,
        )
        summary["arbitrary_tree"] = self.posterior_tree_summary(
            burn_in=burn_in, thin=thin
        )
        return summary

    def _extra_to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "k_max": self.k_max,
            "active_clones": self.active_clones_.copy(),
            "parent_vector": self.parent_vector_.copy(),
            "topological_order": self.topological_order_.copy(),
            "mutation_origins": self.mutation_origin_.copy(),
            "mutation_profile": self.mutation_profile_.copy(),
            "global_clone_weights": self.global_clone_weights_.copy(),
            "activity_probability": float(self.activity_probability_),
            "activity_prior": self.activity_prior,
            "global_weight_concentration": self.global_weight_concentration,
            "move_config": self.move_config,
            "tree_summary_method": self.tree_summary_method,
            "topology_move_diagnostics": self.topology_move_diagnostics(),
            "parent_vector_trace": np.asarray(self.parent_vector_trace_, dtype=np.int64),
            "active_clone_trace": np.asarray(self.active_clone_trace_, dtype=bool),
            "mutation_origin_trace": np.asarray(self.mutation_origin_trace_, dtype=np.int64),
            "global_clone_weight_trace": np.asarray(self.global_clone_weight_trace_, dtype=float),
            "activity_probability_trace": np.asarray(self.activity_probability_trace_, dtype=float),
        }
        if self.parent_vector_trace_:
            out["posterior_tree_summary"] = self.posterior_tree_summary()
        return out
