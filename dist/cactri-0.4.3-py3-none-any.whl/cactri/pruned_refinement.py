"""Backward-compatible imports for :mod:`cactri.pruning`."""

from .pruning import PrunedTreeRefinement, PrunedTreeRefiner

__all__ = ["PrunedTreeRefinement", "PrunedTreeRefiner"]
