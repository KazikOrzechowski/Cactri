# Cactri 0.4.3 test report

Cactri 0.4.3 is an API-compatible refactor that consolidates pruning utilities in `cactri.pruning`.

## Results

- Automated test suite: **79 passed, 0 failed**.
- Canonical imports from `cactri.pruning`: passed.
- Top-level compatibility imports from `cactri`: passed.
- Legacy imports from `cactri.greedy_pruning`, `cactri.read_impurity_splitback`, and `cactri.pruned_refinement`: passed and expose identical class objects.
- Wheel installation in an isolated environment: passed.
- Source distribution rebuilt into a wheel and installed in an isolated environment: passed.
- Wheel-content audit: `cactri/pruning.py` and all three compatibility shims are present.
- Deterministic numerical regression against the prior 0.4.2 wheel: exact equality for greedy cut, split-back cut, clone probabilities, genotype probabilities, cell-genotype probabilities, hard assignments, and refitted mixture proportions.

No inference equations, defaults, or numerical algorithms changed.
