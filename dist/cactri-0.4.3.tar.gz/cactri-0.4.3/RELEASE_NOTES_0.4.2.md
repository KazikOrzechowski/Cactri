# Cactri 0.4.2 release notes

Cactri 0.4.2 introduces `CactriACT`, an arbitrary-clonal-tree subclass of `Cactri`.

## Public API

```python
from cactri import CactriACT, ACTInitializer, ACTMoveConfig
```

`CactriACT` requires explicit `k_max`. Clone 0 is the fixed all-zero reference root. Cells may occupy any internal or terminal clone; no leaf-only mode is implemented.

## Validated ACT formulation

- fixed-dimensional overfitted set of `k_max` clone slots;
- sparse global clone weights;
- arbitrary rooted, unbalanced, and multifurcating topology;
- sampled internal clones;
- strict single-origin mutation inheritance;
- continuous no-spike BCR-hypercluster clone mixtures;
- topology-free initialization;
- leaf parent reassignment and subtree prune-and-regraft;
- mutation origins marginalized when scoring topology proposals;
- clade-mass-weighted mutation-origin prior;
- posterior contraction of redundant or mutation-unidentifiable nodes;
- medoid and majority-clade posterior representatives.

All slots remain available during MCMC and unsupported components are deleted only in posterior summaries. This avoids variable-dimensional split/merge transitions and preserves fixed-shape checkpoints.

## Corrections introduced during validation

The validated build removes an unintended second global allocation term from topology scoring, applies the Hastings correction for leaf-parent proposals, and replaces fixed-origin tree moves with a partially collapsed topology transition. Experimental dynamic split/merge code is excluded from the benchmark because fully derived reversible-jump corrections remain future work.

## Compatibility

`CactriTree`, `CactriOmega`, `BCRInitializer`, clone-mixture APIs, tracking, and checkpoint formats remain compatible with v0.4.1.

## Simulation benchmark

The release was evaluated on 105 `CactriACT` and 105 `CactriTree` chains spanning five simulated patients and seven complete/incomplete scenarios with `msp=0.01` and `ref=0.01`. Raw `CactriACT` achieved 2.9% exact and 10.5% mutation-equivalent topology recovery, versus 8.6% and 8.6% for `CactriTree`. ACT improved equivalent recovery in selected incomplete scenarios but had lower overall cell-clone ARI and genotype MCC. The class should therefore be treated as experimental rather than as the default replacement for `CactriTree`.

Post-inference pruning of `CactriTree` was substantially stronger structurally. Greedy Hamming-BIC pruning with genotype refitting achieved 36.2% exact and 44.8% equivalent recovery, with a mean genotype-MCC change of approximately -0.007 relative to unpruned `CactriTree`.

Medoid and majority ACT summaries tied on all reported recovery endpoints. The medoid remains the default because it weakly minimized posterior mean tree loss and always corresponds to a sampled coherent posterior state.
