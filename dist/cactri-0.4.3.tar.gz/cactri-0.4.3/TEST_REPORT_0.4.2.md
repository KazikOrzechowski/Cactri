# Cactri 0.4.2 test and validation report

## Automated tests

- Test suite: 78/78 passed.
- Coverage includes the legacy Tree and Omega APIs, BCR initialization, clone mixtures, ACT topology validity, all-active cell assignments, inactive-slot exclusion in experimental dynamic mode, checkpoint continuation, and posterior tree summaries, greedy pruning, read-impurity split-back, and pruned genotype/mixture refitting.

## Simulation benchmark

The final benchmark used five simulated patients (K4B--K8B), seven complete/incomplete structural scenarios, three inference seeds, and only `msp=0.01`, `ref=0.01`.

- CactriTree: 105/105 chains.
- CactriACT: 105/105 chains.
- Greedy Hamming-BIC and patient-held-out posterior pruning were evaluated on all 105 Tree fits.
- Mutation genotypes were refitted for pruned cuts before the primary genotype comparison.

Raw CactriACT achieved 2.9% exact and 10.5% mutation-equivalent topology recovery. CactriTree achieved 8.6% for both. Greedy pruning plus genotype refitting achieved 36.2% exact and 44.8% equivalent recovery; held-out posterior pruning plus refitting achieved 23.8% and 31.4%.

CactriACT remains experimental. The default production recommendation remains CactriTree, with optional post-inference pruning and genotype refitting when structural simplification is required.

## Tree-refinement validation

The experimental refinement analysis used 65 retained `CactriTree` traces covering all five patients and all seven complete/incomplete scenarios. The frozen sequence was greedy split-Hamming BIC pruning, read-impurity split-back with penalty scale 0.5, genotype refitting, and one 10% anchored mixture-responsibility update.

- Exact tree recovery: 41.5%.
- Mutation-equivalent recovery: 52.3%.
- Correct clone count: 53.8%.
- Mean normalized RF: 0.181.
- Mean cell-clone ARI: 0.899.
- Mean cell-genotype MCC: 0.780.

Relative to adapted greedy pruning, patient-level bootstrap intervals supported improvements in equivalent topology recovery, correct clone count, normalized RF, and genotype MCC. A training-time prune--split restart did not show a reliable patient-level gain and remains disabled by default.

## Distribution smoke test

- The wheel was installed with `--no-deps` into a fresh virtual environment using system scientific packages.
- Import resolved from the virtual environment site-packages directory, not the source checkout.
- `CactriACT`, `ACTInitializer`, and `ACTMoveConfig` imported successfully.
- A small all-active `CactriACT` fit completed and returned a medoid posterior tree summary.

A fully dependency-isolated offline installation could not be attempted because the execution environment cannot download NumPy and the other declared dependencies.
