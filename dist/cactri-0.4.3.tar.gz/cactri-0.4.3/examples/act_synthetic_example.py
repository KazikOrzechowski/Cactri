"""Small end-to-end example for CactriACT.

Run from a source checkout with:
    PYTHONPATH=src python examples/act_synthetic_example.py
"""

from __future__ import annotations

import numpy as np

from cactri import ACTMoveConfig, CactriACT, TrackingConfig


def make_data(seed: int = 7):
    rng = np.random.default_rng(seed)
    # root, sampled ancestor, descendant, independent branch
    clone_genotypes = np.asarray(
        [
            [0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0],
            [1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1],
        ],
        dtype=np.int8,
    )
    clone_labels = np.repeat(np.arange(4), 30)
    total = rng.poisson(8, size=(clone_labels.size, clone_genotypes.shape[1]))
    probability = np.where(clone_genotypes[clone_labels] == 1, 0.5, 0.001)
    alt = rng.binomial(total, probability)
    modal_bcr = rng.integers(0, 4, size=(4, 12))
    sequences = modal_bcr[clone_labels].copy()
    mutation = rng.random(sequences.shape) < 0.03
    sequences[mutation] = rng.integers(0, 4, size=int(mutation.sum()))
    return sequences, alt, total


def main() -> None:
    sequences, alt, total = make_data()
    model = CactriACT(
        k_max=8,
        initial_active_clones=4,
        random_state=13,
        accelerator="numpy",
        move_config=ACTMoveConfig(
            parent_reassignments=1,
            subtree_regrafts=1,
            split_attempts=1,
            merge_attempts=1,
            min_split_cells=6,
        ),
    )
    model.prefit(
        sequences,
        alt,
        total,
        init="bcr_consensus",
        bcr_initializer_config={
            "n_chains": 2,
            "n_iter": 20,
            "burn_in": 0.5,
            "thin": 2,
            "random_init_clusters": 6,
        },
    )
    model.fit(50, tracking=TrackingConfig())
    model._clear_traces()
    model.fit(
        100,
        tracking=TrackingConfig.posterior(every=2, mixture_diagnostics=True),
    )
    summary = model.posterior_summary(include_partition_medoids=True)
    tree = summary["arbitrary_tree"]
    print("Active slots:", np.flatnonzero(model.active_clones_).tolist())
    print("Current parent vector:", model.parent_vector_.tolist())
    print("Primary tree summary:", tree["primary_method"])
    print("Essentiality:", np.round(tree["clone_essentiality_probabilities"], 3))
    print("Topology moves:", model.topology_move_diagnostics())


if __name__ == "__main__":
    main()
