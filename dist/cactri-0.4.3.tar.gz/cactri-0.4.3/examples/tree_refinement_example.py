"""Minimal post-fit tree-refinement example for Cactri 0.4.3."""

from cactri.pruning import GreedyTreePruner, PrunedTreeRefiner, ReadImpuritySplitBack


def refine_fitted_tree(model):
    """Refine a fitted, posterior-tracked CactriTree model."""
    pruned = GreedyTreePruner(
        state_mode="final",
        min_occupancy=1,
    ).select(model)

    split_back = ReadImpuritySplitBack(
        penalty_scale=0.5,
        prior_mode="global",
    ).select(model, pruned.intervals)

    refined = PrunedTreeRefiner(
        anchor_weight=0.10,
    ).refine(model, split_back.intervals)

    return {
        "greedy_intervals": pruned.intervals,
        "refined_intervals": split_back.intervals,
        "split_decisions": split_back.decisions,
        "cell_clone_probabilities": refined.cell_clone_probability,
        "clone_genotype_probabilities": refined.pruned_clone_genotype_probability,
        "cell_genotype_probabilities": refined.cell_genotype_probability,
        "hypercluster_clone_proportions": refined.hypercluster_clone_proportions,
    }
