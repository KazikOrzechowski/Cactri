"""Compare CactriACT medoid and majority-clade representative summaries."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from cactri import ACTMoveConfig, CactriACT, TrackingConfig


def simulate(seed: int):
    rng = np.random.default_rng(seed)
    profiles = np.asarray(
        [
            [0, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0],
            [1, 1, 1, 0, 0, 0],
            [0, 0, 0, 1, 1, 1],
        ],
        dtype=np.int8,
    )
    labels = np.repeat(np.arange(4), 18)
    total = rng.poisson(7, size=(labels.size, profiles.shape[1]))
    probability = np.where(profiles[labels], 0.5, 0.001)
    alt = rng.binomial(total, probability)
    modal = rng.integers(0, 4, size=(4, 10))
    sequence = modal[labels].copy()
    noise = rng.random(sequence.shape) < 0.04
    sequence[noise] = rng.integers(0, 4, size=int(noise.sum()))
    true_clades = {
        frozenset(np.flatnonzero(np.isin(labels, [1, 2])).tolist()),
        frozenset(np.flatnonzero(labels == 2).tolist()),
        frozenset(np.flatnonzero(labels == 3).tolist()),
    }
    return sequence, alt, total, true_clades


def rf(clades, truth):
    return len(set(clades).symmetric_difference(truth))


def run(replicates: int, output: Path):
    rows = []
    for replicate in range(replicates):
        sequence, alt, total, truth = simulate(1000 + replicate)
        model = CactriACT(
            k_max=7,
            initial_active_clones=4,
            random_state=2000 + replicate,
            accelerator="numpy",
            move_config=ACTMoveConfig(
                parent_reassignments=1,
                subtree_regrafts=1,
                split_attempts=1,
                merge_attempts=1,
                min_split_cells=5,
            ),
        )
        model.prefit(sequence, alt, total, init="random", random_init_clusters=5)
        model.fit(30, tracking=TrackingConfig())
        model._clear_traces()
        model.fit(60, tracking=TrackingConfig.posterior(every=2))
        summary = model.posterior_tree_summary()
        medoid = model._draw_clades(summary["medoid_trace_index"])
        majority = model._draw_clades(summary["majority_trace_index"])
        rows.append(
            {
                "replicate": replicate,
                "medoid_rf": rf(medoid, truth),
                "majority_rf": rf(majority, truth),
                "medoid_exact": int(medoid == truth),
                "majority_exact": int(majority == truth),
            }
        )
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    medoid_rf = np.mean([row["medoid_rf"] for row in rows])
    majority_rf = np.mean([row["majority_rf"] for row in rows])
    medoid_exact = np.mean([row["medoid_exact"] for row in rows])
    majority_exact = np.mean([row["majority_exact"] for row in rows])
    print(f"medoid mean RF={medoid_rf:.3f}, exact={medoid_exact:.3f}")
    print(f"majority mean RF={majority_rf:.3f}, exact={majority_exact:.3f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replicates", type=int, default=12)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("validation/act_tree_summary_benchmark.csv"),
    )
    args = parser.parse_args()
    run(args.replicates, args.output)
