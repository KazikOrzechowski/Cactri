# CactriACT API and model guide

## Constructor

```python
CactriACT(
    *,
    k_max,
    global_weight_concentration=0.2,
    move_config=None,
    topology_initializer=None,
    tree_summary_method="medoid",
    essential_probability_threshold=0.5,
    **cactri_kwargs,
)
```

`k_max` is the number of allocated clone slots, including reference clone 0. The default and validated v0.4.2 ACT formulation is a fixed-dimensional overfitted mixture: all `k_max` slots remain available during MCMC, arrays retain this shape in traces and checkpoints, sparse global weights empty unsupported components, and redundant clones are removed only from posterior summaries.

## All-active assignment

Cells may occupy any internal or terminal clone. There is no leaf-only assignment mode. An internal clone may have both directly assigned cells and active descendants.

## Tree state

- `parent_vector_`: parent slot for every clone; root 0 has parent -1.
- `active_clones_`: fixed all-true slot mask in the validated default formulation.
- `mutation_origin_`: non-reference origin slot for every mutation.
- `mutation_profile_`: clone-by-mutation genotype matrix implied by ancestry.
- `global_clone_weights_`: sparse clone weights learned from cell allocations.

## Topology-free initializer

`ACTInitializer` estimates mutation-presence probabilities, clusters observational units without assuming a tree, infers an acyclic parent vector from profile inclusion, and assigns initial mutation origins. If fewer than `k_max` components are occupied initially, the remaining candidate slots are attached to the root with sparse weight and remain available for inference.

## Topology inference

`ACTMoveConfig` controls leaf parent-reassignment and subtree-prune-and-regraft proposals. Topology proposals are scored using a partially collapsed target that analytically marginalizes mutation origins. Accepted trees are followed by a conditional mutation-origin draw. Mutation-origin priors are proportional to sparse posterior clade mass, so unsupported overfitted leaves do not receive the same prior mass as occupied clones while unsampled ancestors with occupied descendants remain eligible.

The validated default sets `split_attempts=0` and `merge_attempts=0`. Dynamic activation/deactivation remains experimental and is not used in the v0.4.2 benchmark because it requires fully derived reversible-jump proposal corrections. Clone deletion is instead performed after fitting.

ACT v0.4.2 requires `clone_mixture.residual_base="uniform"`; a topology-dependent residual base would require an additional term in the collapsed topology target.

## Posterior summaries

Track with `TrackingConfig.posterior()`, then call:

```python
summary = model.posterior_tree_summary()
```

The sampled-tree medoid minimizes posterior mean descendant-cell-clade symmetric-difference loss. The majority summary selects the retained draw that best represents clades with posterior support above 0.5. Both are returned for empirical comparison.

`sampled_population_tree` contracts redundant unoccupied nodes. `mutation_identifiable_tree` additionally contracts one-child edges with no mutation origin. Compact records reindex retained nodes and include aligned genotype matrices and cell assignments. `posterior_retained_clone_mask()` reports slots passing a posterior essentiality threshold.
