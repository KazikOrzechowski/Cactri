# ACT architecture

`CactriACT` inherits BCR clustering, cell-level no-spike mixtures, mutation-read likelihoods, observation-probability updates, CRP concentration updates, tracking, and checkpointing from `Cactri`.

The subclass replaces the genotype prior with five fixed-size state arrays:

1. active clone mask;
2. parent vector;
3. topological ordering;
4. mutation-origin vector;
5. arbitrary-tree mutation profile.

The descendant matrix is rebuilt from the parent vector when topology changes. The clone-by-mutation profile is obtained by indexing descendant patterns with mutation origins.

Inactive slots are retained in arrays but masked from clone-mixture updates. Posterior contraction is a summary operation and never changes trace dimensions.
