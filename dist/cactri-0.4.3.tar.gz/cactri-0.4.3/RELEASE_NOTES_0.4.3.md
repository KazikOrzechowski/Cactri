# Cactri 0.4.3

Cactri 0.4.3 is an API-compatible packaging refactor.

- Consolidated all tree-pruning, read split-back, and post-pruning refinement implementations in `cactri.pruning`.
- The canonical import path is now `from cactri.pruning import ...`.
- Top-level imports from `cactri` remain supported.
- The former implementation modules remain compatibility shims and return the same class objects.
- No inference equations, defaults, or numerical behavior were changed.
