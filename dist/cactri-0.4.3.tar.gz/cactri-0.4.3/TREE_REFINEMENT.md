# Greedy tree refinement

Cactri v0.4.3 exposes the experimental three-stage post-fit refinement pipeline for `CactriTree` through `cactri.pruning`:

1. `GreedyTreePruner` selects a dyadic tree cut using the split-Hamming BIC.
2. `ReadImpuritySplitBack` reopens a collapsed block when its two children improve soft read prediction enough to overcome a BIC penalty.
3. `PrunedTreeRefiner` refits clone genotypes and performs one anchored update of BCR-hypercluster clone mixtures and cell-clone probabilities.

```python
from cactri.pruning import (
    GreedyTreePruner,
    ReadImpuritySplitBack,
    PrunedTreeRefiner,
)

pruned = GreedyTreePruner(
    state_mode="final",
    min_occupancy=1,
).select(model)

split_back = ReadImpuritySplitBack(
    penalty_scale=0.5,
    prior_mode="global",
).select(model, pruned.intervals)

refined = PrunedTreeRefiner(anchor_weight=0.10).refine(
    model,
    split_back.intervals,
)
```

For large traces, pass a precomputed coherent clone-trace index and hypercluster assignment to avoid recomputing partition medoids:

```python
split_back = ReadImpuritySplitBack().select(
    model,
    pruned.intervals,
    clone_trace_index=clone_medoid_index,
    hypercluster_assignment=hypercluster_medoid,
)
refined = PrunedTreeRefiner().refine(
    model,
    split_back.intervals,
    hypercluster_assignment=hypercluster_medoid,
)
```

## Interpretation

The read split-back score is

\[
2\Delta\ell_{\mathrm{read}}-\lambda d\log(n_{\mathrm{eff}}),
\]

where `d` is the Hamming distance between the union genotypes of the two child subtrees. A positive score triggers a recursive split. The benchmark-supported experimental value is `penalty_scale=0.5`.

Clone-mixture evidence is not added to the pruning BIC. Instead, mixtures are conditionally refit after selecting the cut. The supported update is deliberately tempered: 90% of each original posterior allocation is retained and 10% comes from the refitted mutation-read and mixture responsibility.

## Training-time use

A single prune–split refresh between two warm-up phases was evaluated. It remains experimental because patient-level uncertainty did not establish a reliable gain. Do not alter the tree during retained sampling. Any refresh should be followed by a new discarded warm-up phase before posterior collection.
