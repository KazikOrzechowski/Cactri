# Migration to Cactri 0.4.2

Existing `CactriTree` and `CactriOmega` code requires no changes.

```python
from cactri import CactriACT, TrackingConfig

model = CactriACT(k_max=12, random_state=1)
model.prefit(bcr_sequences, alt_counts, total_counts, init="bcr_consensus")
model.fit(1000)
model._clear_traces()
model.fit(500, tracking=TrackingConfig.posterior(every=5))
summary = model.posterior_tree_summary()
```

`k_max` is mandatory. All candidate slots remain available during inference; sparse weights and posterior contraction determine the reported clone set. Cells are always allowed to occupy internal as well as terminal clones.

ACT currently requires the continuous no-spike clone mixture with `allow_pure_hyperclusters=False` and `residual_base="uniform"`.
