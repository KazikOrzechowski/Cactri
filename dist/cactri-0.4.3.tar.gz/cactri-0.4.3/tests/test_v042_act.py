from __future__ import annotations

import copy
from pathlib import Path

import numpy as np

from cactri import (
    ACTInitializer,
    ACTMoveConfig,
    CactriACT,
    TrackingConfig,
    __version__,
)


def _synthetic(seed: int = 2):
    rng = np.random.default_rng(seed)
    profiles = np.asarray(
        [
            [0, 0, 0, 0],
            [1, 0, 0, 0],
            [1, 1, 0, 0],
            [0, 0, 1, 1],
        ],
        dtype=np.int8,
    )
    labels = np.repeat(np.arange(4), 20)
    total = np.full((labels.size, profiles.shape[1]), 16, dtype=np.int64)
    probability = np.where(profiles[labels] == 1, 0.5, 0.001)
    alt = rng.binomial(total, probability).astype(np.int64)
    sequences = rng.integers(0, 4, size=(labels.size, 7), dtype=np.int64)
    return sequences, alt, total, labels, profiles


def _model(seed: int = 10) -> CactriACT:
    return CactriACT(
        k_max=7,
        initial_active_clones=4,
        dynamic_activity=True,
        random_state=seed,
        accelerator="numpy",
        move_config=ACTMoveConfig(
            parent_reassignments=1,
            subtree_regrafts=1,
            split_attempts=1,
            merge_attempts=1,
            min_split_cells=4,
        ),
    )


def test_public_version_and_initializer_recover_nested_profile():
    assert __version__ == "0.4.3"
    _, alt, total, labels, profiles = _synthetic()
    initializer = ACTInitializer(
        k_max=7,
        initial_active_clones=4,
        random_state=1,
    ).fit(alt, total)
    assert initializer.active_clones_[0]
    assert initializer.parent_vector_[0] == -1
    assert np.all(initializer.parent_vector_[initializer.active_clones_][1:] >= 0)
    assert initializer.cell_clone_assignments_.shape == labels.shape
    recovered = {
        tuple(row.tolist())
        for row in initializer.genotype_matrix_[initializer.active_clones_]
    }
    expected = {tuple(row.tolist()) for row in profiles}
    assert recovered == expected
    # The [1, 1, 0, 0] clone must descend from [1, 0, 0, 0].
    active = np.flatnonzero(initializer.active_clones_)
    rows = initializer.genotype_matrix_
    child = next(int(k) for k in active if tuple(rows[k]) == (1, 1, 0, 0))
    parent = next(int(k) for k in active if tuple(rows[k]) == (1, 0, 0, 0))
    assert initializer.parent_vector_[child] == parent


def test_act_allows_cells_on_internal_clones_and_keeps_valid_topology():
    sequences, alt, total, _, _ = _synthetic()
    model = _model()
    model.prefit(sequences, alt, total, init="random", random_init_clusters=5)
    model.fit(
        12,
        assignment_sampler="approximate",
        tracking=TrackingConfig.posterior(every=1),
    )
    model._validate_topology()
    assert np.all(model.active_clones_[model.current_cell_clone_assignment()])
    # Construct an explicit sampled-ancestor state: clone 1 has assigned cells
    # and active child clone 2. The all-active model accepts this state.
    active = model.active_clones_.copy()
    active[:4] = True
    active[4:] = False
    parent = np.full(model.k_max, -1, dtype=np.int64)
    parent[0] = -1
    parent[1] = 0
    parent[2] = 1
    parent[3] = 0
    model.active_clones_ = active
    model.parent_vector_ = parent
    model.cell_clone_assignments_[:8] = 1
    model.cell_clone_assignments_[8:16] = 2
    model._validate_topology()
    children = model._children(model.parent_vector_, model.active_clones_)
    occupied = np.bincount(model.current_cell_clone_assignment(), minlength=model.k_max)
    assert occupied[1] > 0
    assert children[1] == [2]
    summary = model.posterior_tree_summary()
    assert summary["primary_method"] == "medoid"
    assert summary["sampled_population_tree"]["active_clones"].shape == (model.k_max,)
    assert summary["mutation_identifiable_tree"]["parent_vector"].shape == (model.k_max,)
    assert summary["posterior_retained_clone_mask"].shape == (model.k_max,)
    assert summary["sampled_population_compact"]["genotype_matrix"].shape[1] == model.n_snv
    assert summary["mutation_identifiable_compact"]["parent_vector"][0] == -1


def test_inactive_clones_have_zero_assignment_probability():
    sequences, alt, total, _, _ = _synthetic()
    model = _model()
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    inactive = ~model.active_clones_
    assert np.all(model.hypercluster_clone_proportions_[:, inactive] == 0.0)
    for _ in range(4):
        model._sample_cell_clone_assignments()
        assert not np.any(inactive[model.cell_clone_assignments_])


def test_checkpoint_restart_is_exact_for_act(tmp_path: Path):
    sequences, alt, total, _, _ = _synthetic(7)
    model = _model(seed=91)
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    tracking = TrackingConfig.posterior(every=1)
    model.fit(4, tracking=tracking)
    checkpoint = model.save_checkpoint(tmp_path / "act.pkl.gz")
    resumed = CactriACT.load_checkpoint(checkpoint, accelerator="numpy")
    continued = copy.deepcopy(model)
    resumed.fit(4, tracking=tracking)
    continued.fit(4, tracking=tracking)
    np.testing.assert_array_equal(resumed.parent_vector_, continued.parent_vector_)
    np.testing.assert_array_equal(resumed.active_clones_, continued.active_clones_)
    np.testing.assert_array_equal(resumed.mutation_origin_, continued.mutation_origin_)
    np.testing.assert_array_equal(
        resumed.current_cell_clone_assignment(), continued.current_cell_clone_assignment()
    )
    np.testing.assert_allclose(resumed.global_clone_weights_, continued.global_clone_weights_)


def test_tree_summaries_are_label_invariant_through_cell_clades():
    sequences, alt, total, _, _ = _synthetic(11)
    model = _model(seed=13)
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    model.fit(8, tracking=TrackingConfig.posterior(every=1))
    summary = model.posterior_tree_summary()
    assert summary["medoid_trace_index"] >= 0
    assert summary["majority_trace_index"] >= 0
    assert summary["mean_rf_loss_medoid"] <= summary["mean_rf_loss_majority"] + 1e-12
    essential = summary["clone_essentiality_probabilities"]
    assert essential.shape == (model.k_max,)
    assert essential[0] == 1.0
    assert np.all((essential >= 0.0) & (essential <= 1.0))


def test_topology_moves_preserve_array_shapes_and_validity():
    sequences, alt, total, _, _ = _synthetic(23)
    model = _model(seed=22)
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    for _ in range(20):
        model._sample_genotype_state()
        model._update_genotype_prior_parameters()
        model._validate_topology()
        assert model.parent_vector_.shape == (model.k_max,)
        assert model.active_clones_.shape == (model.k_max,)
        assert model.mutation_profile_.shape == (model.k_max, model.n_snv)
        assert np.all(model.active_clones_[model.mutation_origin_])
        assert np.all(model.mutation_origin_ != 0)


def test_initializer_respects_supplied_group_pooling():
    sequences, alt, total, _, _ = _synthetic(31)
    groups = np.repeat(np.arange(8), 10)
    initializer = ACTInitializer(
        k_max=7,
        initial_active_clones=4,
        random_state=3,
    ).fit(alt, total, group_assignments=groups)
    for group in np.unique(groups):
        assigned = initializer.cell_clone_assignments_[groups == group]
        assert np.unique(assigned).size == 1


def test_supported_split_activation_is_operational():
    rng = np.random.default_rng(44)
    n_per_group = 20
    # Two strongly distinct mutation groups are initially forced into one
    # occupied non-reference clone. A valid split must be able to activate an
    # unused child and move one complete BCR group into it.
    groups = np.repeat(np.arange(2), n_per_group)
    n = groups.size
    profiles = np.asarray([[1, 0, 0, 0], [1, 1, 1, 0]], dtype=np.int8)
    total = np.full((n, 4), 30, dtype=np.int64)
    probability = np.where(profiles[groups] == 1, 0.5, 0.001)
    alt = rng.binomial(total, probability).astype(np.int64)
    sequences = np.tile(np.arange(4, dtype=np.int64), (n, 2))[:, :7]
    sequences = rng.integers(0, 4, size=(n, 7), dtype=np.int64)
    sequences[groups == 0, 0] = 0
    sequences[groups == 1, 0] = 3

    model = CactriACT(
        k_max=5,
        initial_active_clones=2,
        random_state=45,
        accelerator="numpy",
        move_config=ACTMoveConfig(
            parent_reassignments=0,
            subtree_regrafts=0,
            split_attempts=1,
            merge_attempts=0,
            min_split_cells=4,
        ),
    )
    model.prefit(sequences, alt, total, init=groups, random_init_clusters=2)

    # Force an intentionally underfitted active state: root plus one occupied
    # clone carrying both mutation groups.
    model.active_clones_[:] = False
    model.active_clones_[:2] = True
    model.parent_vector_[:] = -1
    model.parent_vector_[1] = 0
    model.cell_clone_assignments_[:] = 1
    model.assignments_ = groups.copy()
    model.mutation_origin_[:] = 1
    model.global_clone_weights_[:] = 0.0
    model.global_clone_weights_[:2] = 0.5
    model._refresh_mutation_profile()
    model.hypercluster_to_clone_[:] = 1
    model.hypercluster_clone_proportions_[:] = 0.0
    model.hypercluster_clone_proportions_[:, 1] = 1.0
    model.admixture_mass_[:] = 0.0
    model.residual_clone_proportions_[:] = 0.0
    model._renormalize_mixture_support()

    for _ in range(40):
        model._propose_split()
        if model.topology_move_accepts_["split"] > 0:
            break

    assert model.topology_move_attempts_["split"] > 0
    assert model.topology_move_accepts_["split"] > 0
    assert np.count_nonzero(model.active_clones_) >= 3
    model._validate_topology()


def test_topology_target_uses_global_weights_only_as_origin_base():
    sequences, alt, total, _, _ = _synthetic(52)
    model = _model(seed=53)
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    cells = model.current_cell_clone_assignment().copy()
    old_weights = model._origin_prior_weights(model.parent_vector_, model.active_clones_).copy()
    baseline = model._state_log_target(
        model.parent_vector_, model.active_clones_, model.mutation_origin_, cells
    )
    active = np.flatnonzero(model.active_clones_)
    altered = np.zeros(model.k_max, dtype=float)
    altered[active] = np.linspace(1.0, 20.0, active.size)
    altered /= altered.sum()
    model.global_clone_weights_ = altered
    model._set_clone_prior_from_global_weights()
    new_weights = model._origin_prior_weights(model.parent_vector_, model.active_clones_)
    changed = model._state_log_target(
        model.parent_vector_, model.active_clones_, model.mutation_origin_, cells
    )
    expected = np.log(new_weights[model.mutation_origin_]).sum() - np.log(
        old_weights[model.mutation_origin_]
    ).sum()
    assert np.isclose(changed - baseline, expected)


def test_parent_reassignment_uses_collapsed_target_then_resamples_origins(monkeypatch):
    sequences, alt, total, _, _ = _synthetic(61)
    model = _model(seed=62)
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    candidates = model._active_indices()[1:].astype(np.int64)
    replacement = np.full(model.n_snv, int(candidates[0]), dtype=np.int64)
    calls = []
    # Equal collapsed targets guarantee acceptance because log(U) < 0 almost surely.
    monkeypatch.setattr(
        model, "_collapsed_topology_log_target", lambda *args, **kwargs: 0.0
    )
    def fake_scores(parent, active, cells, **kwargs):
        calls.append(np.asarray(parent).copy())
        scores = np.full((model.n_snv, candidates.size), -1000.0)
        scores[:, 0] = 0.0
        return candidates.copy(), scores
    monkeypatch.setattr(model, "_origin_log_scores", fake_scores)
    for _ in range(20):
        before = model.topology_move_accepts_["parent_reassignment"]
        model._propose_parent_reassignment(leaf_only=True)
        if model.topology_move_accepts_["parent_reassignment"] > before:
            break
    assert model.topology_move_accepts_["parent_reassignment"] > 0
    assert calls
    np.testing.assert_array_equal(model.mutation_origin_, replacement)
    model._validate_topology()


def test_default_act_is_fixed_dimensional_overfitted_mixture():
    sequences, alt, total, _, _ = _synthetic(71)
    model = CactriACT(
        k_max=7,
        initial_active_clones=3,
        random_state=72,
        accelerator="numpy",
        move_config=ACTMoveConfig(
            parent_reassignments=1,
            subtree_regrafts=1,
            split_attempts=2,
            merge_attempts=2,
        ),
    )
    model.prefit(sequences, alt, total, init="random", random_init_clusters=4)
    assert model.dynamic_activity is False
    assert np.all(model.active_clones_)
    before = model.active_clones_.copy()
    model._sample_genotype_state()
    np.testing.assert_array_equal(model.active_clones_, before)
    assert model.topology_move_attempts_["split"] == 0
    assert model.topology_move_attempts_["merge"] == 0
    model._validate_topology()
