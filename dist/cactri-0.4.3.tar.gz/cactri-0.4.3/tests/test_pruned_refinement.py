import numpy as np
from cactri import CactriTree, CloneMixtureConfig, TrackingConfig
from cactri.pruning import PrunedTreeRefiner


def test_pruned_refiner_shapes_and_normalization():
    rng=np.random.default_rng(4);n=24;m=7;l=5
    seq=rng.integers(0,4,size=(n,l));total=rng.integers(0,4,size=(n,m));alt=np.minimum(total,rng.binomial(total,.2))
    z=np.repeat(np.arange(4),6)
    model=CactriTree(n_levels=2,random_state=9,clone_mixture=CloneMixtureConfig(enabled=True,allow_pure_hyperclusters=False,admixture_mass_prior=(1,19),residual_concentration=.2))
    model.prefit(seq,alt,total,init=z)
    model.fit(10,tracking=TrackingConfig.posterior(every=1,observation_probabilities=True))
    result=PrunedTreeRefiner(anchor_weight=.1).refine(model,((0,2),(2,3),(3,4)))
    assert result.cell_clone_probability.shape==(n,4)
    assert result.pruned_clone_genotype_probability.shape==(3,m)
    assert result.cell_genotype_probability.shape==(n,m)
    np.testing.assert_allclose(result.cell_clone_probability.sum(1),1)
    np.testing.assert_allclose(result.hypercluster_clone_proportions.sum(1),1)
    assert np.all((result.cell_genotype_probability>=0)&(result.cell_genotype_probability<=1))


def test_pruned_refiner_rejects_incomplete_cut():
    rng=np.random.default_rng(2);seq=rng.integers(0,4,size=(12,3));total=np.ones((12,4),int);alt=np.zeros_like(total)
    model=CactriTree(n_levels=2,random_state=3,clone_mixture=CloneMixtureConfig(enabled=True,allow_pure_hyperclusters=False))
    model.prefit(seq,alt,total,init=np.repeat(np.arange(3),4));model.fit(3,tracking=TrackingConfig.posterior(every=1,observation_probabilities=True))
    try:
        PrunedTreeRefiner().refine(model,((0,1),(2,4)))
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')
