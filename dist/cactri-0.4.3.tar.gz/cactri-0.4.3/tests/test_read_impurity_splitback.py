import numpy as np
from cactri.pruning import ReadImpuritySplitBack

class Dummy:
    n_leaf_clones=4
    def __init__(self):
        # Two cells repeatedly assigned to opposite leaves in the first block.
        self.cell_clone_assignment_trace_=[np.array([1,2]),np.array([1,2])]
        g=np.zeros((5,1),dtype=np.int8);g[1,0]=1
        self.genotype_state_trace_=[g,g]
        self.p_obs_by_mutation_trace_=[np.array([.9]),np.array([.9])]
        self.p_unobs_trace_=[.001,.001]
        self.alt_counts_=np.array([[10.],[0.]])
        self.total_counts_=np.array([[10.],[10.]])
    def posterior_clone_partition_medoid(self):return {'assignment':np.array([1,2]),'trace_index':0,'losses':np.zeros(2)}
    def posterior_hypercluster_partition_medoid(self):return {'assignment':np.array([0,0]),'trace_index':0,'losses':np.zeros(2)}

def test_read_supported_split_is_accepted():
    out=ReadImpuritySplitBack(penalty_scale=.5).select(Dummy(),[(0,2),(2,4)])
    assert out.intervals==((0,1),(1,2),(2,4))
    assert out.decisions[0].accepted

def test_high_penalty_keeps_collapsed_block():
    out=ReadImpuritySplitBack(penalty_scale=100).select(Dummy(),[(0,2),(2,4)])
    assert out.intervals==((0,2),(2,4))

def test_invalid_cut_rejected():
    import pytest
    with pytest.raises(ValueError):ReadImpuritySplitBack().select(Dummy(),[(0,3),(3,4)])
