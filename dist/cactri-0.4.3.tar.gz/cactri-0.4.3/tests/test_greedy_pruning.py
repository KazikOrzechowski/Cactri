import numpy as np
from cactri.pruning import GreedyTreePruner
class Dummy:
 n_leaf_clones=2;n_snv=2;n_cells=4
 cell_clone_assignments_=np.array([1,1,2,2])
 mutation_profile_=np.array([[0,0],[1,0],[1,1]],dtype=np.int8)
 p_obs_by_mutation_=np.array([.9,.9]);p_unobs_=.001
 alt_counts_=np.array([[9,0],[8,0],[9,0],[8,0]],float)
 total_counts_=np.array([[10,0],[10,0],[10,0],[10,0]],float)
def test_unsupported_split_difference_collapses():
 out=GreedyTreePruner().select(Dummy())
 assert out.intervals==((0,2),)
 assert len(out.history)==1
 assert out.history[0].parameter_saving==1
